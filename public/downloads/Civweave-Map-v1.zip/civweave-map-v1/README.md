# Civweave Map v1

Civweave Map v1 is the portable Federation Finder map runtime. Serve this directory over HTTP and open `/app/federation-finder-map-v275.html`.

## Offline behavior

- MapLibre and PMTiles are packaged locally; no CDN is required for the map runtime.
- The full pinned federation/contact atlas is bundled in this archive for clean-install offline discovery.
- A local coordinate-field basemap appears when no downloaded PMTiles region is available.
- Federated PMTiles regions are streamed into chunked IndexedDB storage, SHA-256 verified, and rendered directly from that local store.

## Privacy

Device geolocation is session-only and is never automatically published to the Civweave mesh. Only explicitly public locality and node metadata federate.

## Node freshness

Federated node-location status is marked stale after six hours and expires after twenty-four hours unless refreshed.
