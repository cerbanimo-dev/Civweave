# School of Science

Contains 213 foundational articles and 6443 searchable sections. Use the bundle catalog for cross-school routing.
