# School of Philosophy and Religion

Contains 57 foundational articles and 2183 searchable sections. Use the bundle catalog for cross-school routing.
