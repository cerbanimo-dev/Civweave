# School of Health, Medicine and Disease

Contains 42 foundational articles and 1433 searchable sections. Use the bundle catalog for cross-school routing.
