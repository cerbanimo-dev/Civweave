# School of History

Contains 86 foundational articles and 3400 searchable sections. Use the bundle catalog for cross-school routing.
