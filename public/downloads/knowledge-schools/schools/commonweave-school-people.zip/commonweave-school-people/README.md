# School of People and Lives

Contains 110 foundational articles and 3351 searchable sections. Use the bundle catalog for cross-school routing.
