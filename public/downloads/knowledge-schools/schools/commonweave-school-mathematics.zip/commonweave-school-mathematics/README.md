# School of Mathematics

Contains 45 foundational articles and 1258 searchable sections. Use the bundle catalog for cross-school routing.
