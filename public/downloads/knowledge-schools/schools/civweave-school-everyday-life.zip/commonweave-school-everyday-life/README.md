# School of Everyday Life

Contains 56 foundational articles and 1682 searchable sections. Use the bundle catalog for cross-school routing.
