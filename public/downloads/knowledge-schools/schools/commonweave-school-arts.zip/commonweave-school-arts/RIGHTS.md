Wikipedia article text is CC BY-SA 4.0. Canonical URLs, revision IDs, timestamps, retrieval times, and attribution are retained. External resources are references unless separately reviewed.
