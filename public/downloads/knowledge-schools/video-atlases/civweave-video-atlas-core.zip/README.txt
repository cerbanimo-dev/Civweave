Civweave Video Learning Atlas — complete core
Built: 2026-08-09T21:53:00Z
Records: 2750 across 11 foundation schools.
No video binaries are included. Follow the YouTube URLs when online.
Source-dataset text/provenance is durable; YouTube Data API descriptions are kept in a separate expiring sidecar.
