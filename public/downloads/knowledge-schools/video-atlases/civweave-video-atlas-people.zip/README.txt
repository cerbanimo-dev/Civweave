Civweave Video Learning Atlas — School of People and Lives
Built: 2026-08-09T21:53:00Z
This package contains links and lightweight metadata only; it contains no YouTube video files.
Descriptions in this durable package come only from source-dataset text with compatible provenance.
Current YouTube API descriptions, when available, are distributed separately as a 30-day refresh sidecar.
