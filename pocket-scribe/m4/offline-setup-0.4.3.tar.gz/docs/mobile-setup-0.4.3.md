# Pocket Scribe 0.4.3 — offline phone setup and safe-area fix

- Native WindowInsets used on Android 15/16; prevents status/nav bar overlays on WebView and handles IME opening.
- In-app setup before sermon list. User must explicitly confirm downloads; nothing downloads automatically.
- Qwen 3.5 4B Q4_K_M from SoAIHQ Hugging Face, HTTPS with resumable Range, 206 Content-Range verification, storage checks, and pinned SHA-256 `2ebe6eb67cb92adeffc7073c48dd4e3baf79465ac650793dc751cad2b29cf219`.
- Kokoro archive from sherpa-onnx release; unpack and validate required files. Supports existing local import alternative.
- Download in app-private storage; do not uninstall existing app unless project exports are safe; different package names never share their resources automatically.
- Keep the phone unlocked and the app foreground during download; no background service has been implemented. Pause/resume available for Qwen. Large download uses mobile data if Wi-Fi is unavailable; use Wi-Fi recommended.
- The app's baseline manual sermon features still work even with no models. Non-bundled model weights require one-time network download.
- Build verification is distinct from on-device validation. Test on Galaxy S25+: status bar inset, keyboard inset, offline after setup, model installation and first Qwen generation, Kokoro read-aloud.
