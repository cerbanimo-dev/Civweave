package org.kingdom.pocketscribe;

import android.net.Uri;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.function.BooleanSupplier;

/** Explicit user-initiated HTTPS download, resumable and verified before activation.
 * Partial files are retained after cancellation or a network failure.
 * No background service is claimed: keep the app open until completion.
 */
public final class ModelDownload {
    private static final long MIB=1024L*1024L;
    private static final long RESERVE=384*MIB;
    private static final long QWEN_MAX=4_000_000_000L;
    private static final long QWEN_MIN=2_000_000_000L;
    private static final long KOKORO_MAX=1_300_000_000L;
    private static final long KOKORO_MIN=20_000_000L;
    // Pinned to the published SoAIHQ Q4_K_M file SHA-256. Prevents an HTML
    // download page, partial weight set, or altered file being marked ready.
    private static final String QWEN_SHA256="2ebe6eb67cb92adeffc7073c48dd4e3baf79465ac650793dc751cad2b29cf219";
    private static final String QWEN_URL="https://huggingface.co/SoAIHQ/Qwen3.5-4B-GGUF/resolve/main/Qwen3.5-4B-Q4_K_M.gguf";
    private static final String KOKORO_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_0.tar.bz2";
    private final ModelInstaller models;
    public ModelDownload(ModelInstaller models){this.models=models;}

    public void downloadQwen(ModelInstaller.Progress progress,BooleanSupplier stopped) throws Exception {
        if(models.hasQwen()){progress.update("Qwen already installed");return;}
        File temp=models.qwenDownloadPartial();
        boolean verified=false;
        // Interrupted verification may have left a complete file. Verify before
        // asking the server for more bytes (which would return HTTP 416).
        if(temp.isFile() && temp.length()>2_600_000_000L){
            progress.update("Checking whether the existing partial is complete…");
            try{
                checkGGUF(temp);
                sha256Check(temp,QWEN_SHA256,progress,stopped);
                verified=true;
            }catch(InterruptedIOException paused){throw paused;}
            catch(IOException incomplete){progress.update("Partial model needs more data; resuming…");}
        }
        if(!verified){
            download(QWEN_URL,temp,QWEN_MIN,QWEN_MAX,2_800_000_000L,"Qwen3.5",progress,stopped);
            checkGGUF(temp);
            try{sha256Check(temp,QWEN_SHA256,progress,stopped);}
            catch(IOException invalid){
                if(invalid.getMessage()!=null && invalid.getMessage().contains("SHA-256 mismatch"))temp.delete();
                throw invalid;
            }
        }
        Files.move(temp.toPath(),models.qwen().toPath(),StandardCopyOption.REPLACE_EXISTING);
        if(!models.hasQwen())throw new IOException("Model activation failed after download");
    }
    public void downloadKokoro(ModelInstaller.Progress progress,BooleanSupplier stopped) throws Exception {
        if(models.hasKokoro()){progress.update("Kokoro already installed");return;}
        File temp=models.kokoroDownloadPartial();
        download(KOKORO_URL,temp,KOKORO_MIN,KOKORO_MAX,390_000_000L,"Kokoro",progress,stopped);
        progress.update("Download complete · unpacking Kokoro voice pack…");
        // ContentResolver supports a file: Uri for our own private staging file.
        models.importKokoro(Uri.fromFile(temp),progress);
        if(!models.hasKokoro())throw new IOException("Kokoro unpack completed but required files are missing");
        temp.delete();
    }

    private void download(String source,File partial,long min,long max,long nominal,String label,
                          ModelInstaller.Progress progress,BooleanSupplier stopped) throws Exception {
        File dir=models.base();
        if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Cannot create models directory");
        long existing=partial.isFile()?partial.length():0;
        if(existing>max){if(!partial.delete())throw new IOException("Invalid oversized partial; free app storage");existing=0;}
        long expectedRemaining=Math.max(0,nominal-existing);
        if(models.freeStorageBytes()<expectedRemaining+RESERVE)
            throw new IOException("Not enough phone storage. Free about "+giB(expectedRemaining+RESERVE)+" GiB; currently available "+giB(models.freeStorageBytes())+" GiB.");
        HttpURLConnection connection=null;
        try{
            URL url=new URL(source);
            for(int redirects=0;redirects<9;redirects++){
                if(stopped.getAsBoolean())throw new InterruptedIOException("Download paused. Tap Download again to resume.");
                if(!url.getProtocol().equals("https"))throw new IOException("Refusing an insecure model download redirect");
                connection=(HttpURLConnection)url.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(25_000);
                connection.setReadTimeout(25_000);
                connection.setRequestProperty("Accept-Encoding","identity");
                connection.setRequestProperty("User-Agent","PocketScribe/0.4.3 (Android; local model installer)");
                if(existing>0)connection.setRequestProperty("Range","bytes="+existing+"-");
                int status=connection.getResponseCode();
                if(status==301||status==302||status==303||status==307||status==308){
                    String location=connection.getHeaderField("Location");
                    if(location==null)throw new IOException("Model host redirected without a destination");
                    URL next=new URL(url,location);
                    connection.disconnect();connection=null;url=next;continue;
                }
                if(status==416){connection.disconnect();connection=null;
                    if(partial.delete())throw new IOException("Remote model rejected resume. Old partial cleared; tap Download again to restart.");
                    throw new IOException("Remote model rejected resume; free app storage and retry.");}
                if(status!=200&&status!=206)
                    throw new IOException("Model server returned HTTP "+status+". Check your Wi-Fi or import a downloaded GGUF manually.");
                boolean append=status==206;
                if(append){
                    String range=connection.getHeaderField("Content-Range");
                    if(existing==0||range==null||!range.startsWith("bytes "+existing+"-"))
                        throw new IOException("Server returned an unexpected byte range; refusing to corrupt the model");
                } else existing=0; // Range was ignored: safely restart from byte zero.
                String contentType=connection.getContentType();
                if(contentType!=null && (contentType.contains("text/html")||contentType.contains("application/json")))
                    throw new IOException("Model server returned a page, not a model file. Use Import file instead.");
                long length=connection.getContentLengthLong();
                long total=length>=0?length+existing:-1;
                if(total>max)throw new IOException("Remote model is unexpectedly large: "+giB(total)+" GiB");
                if(models.freeStorageBytes()<Math.max(0,(total>0?total:nominal)-existing)+RESERVE)
                    throw new IOException("Insufficient storage to finish downloading "+label);
                long current=existing, lastReport=current;
                progress.update((append?"Resuming ":"Downloading ")+label+" · "+mb(current)+" MiB received. Keep the app open.");
                try(InputStream in=new BufferedInputStream(connection.getInputStream(),256*1024);
                    FileOutputStream stream=new FileOutputStream(partial,append);
                    OutputStream out=new BufferedOutputStream(stream,256*1024)){
                    byte[] buffer=new byte[256*1024];int n;
                    while((n=in.read(buffer))!=-1){
                        if(stopped.getAsBoolean())throw new InterruptedIOException("Download paused at "+mb(current)+" MiB. Tap Download to resume.");
                        if(n==0)continue;
                        out.write(buffer,0,n);current+=n;
                        if(current>max)throw new IOException("Downloaded file exceeds expected maximum size");
                        if(current-lastReport>=8*MIB){
                            lastReport=current;
                            String percentage=total>0?" ("+Math.min(99,current*100/total)+"%)":"";
                            progress.update("Downloading "+label+": "+mb(current)+" MiB"+(total>0?" of "+mb(total)+" MiB":"")+percentage+" · keep app open");
                        }
                    }
                    out.flush();stream.getFD().sync();
                }
                if(current<min)throw new IOException("Only "+mb(current)+" MiB received. Download incomplete; retry to resume.");
                if(total>0 && current!=total)throw new IOException("Download stopped at "+mb(current)+" of "+mb(total)+" MiB. Retry to resume.");
                progress.update(label+" downloaded ("+mb(current)+" MiB) · validating…");
                return;
            }
            throw new IOException("Too many model-host redirects");
        }finally{if(connection!=null)connection.disconnect();}
    }
    private static void checkGGUF(File f) throws Exception {
        try(RandomAccessFile file=new RandomAccessFile(f,"r")){
            if(file.read()!='G'||file.read()!='G'||file.read()!='U'||file.read()!='F')
                throw new IOException("Not a GGUF file. Download may have returned an HTML error page.");
            int v=Integer.reverseBytes(file.readInt());
            if(v!=3)throw new IOException("Expected GGUF v3, got "+v);
        }
    }
    private static void sha256Check(File f,String expected,ModelInstaller.Progress progress,BooleanSupplier stopped) throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        progress.update("Verifying full Qwen model checksum (SHA-256)…");
        try(InputStream in=new BufferedInputStream(new FileInputStream(f),4*1024*1024)){
            byte[] buffer=new byte[4*1024*1024];int n;
            while((n=in.read(buffer))!=-1){
                if(stopped.getAsBoolean())throw new InterruptedIOException("Verification paused. Tap Download to continue.");
                digest.update(buffer,0,n);
            }
        }
        byte[] sum=digest.digest();StringBuilder actual=new StringBuilder();
        for(byte b:sum)actual.append(String.format(Locale.US,"%02x",b&255));
        if(!expected.equals(actual.toString()))throw new IOException("SHA-256 mismatch: download is incomplete or corrupted. Delete and re-download the model. Expected "+expected.substring(0,12)+"…");
    }
    private static long mb(long n){return n/MIB;}
    private static String giB(long n){return String.format(Locale.US,"%.2f",n/(1024.0*1024*1024));}
}
