# Kingdom of Heaven — Pocket Scribe 0.4.1 (Galaxy S25+)

**GitHub Actions has successfully compiled an ARM64 debug APK. Galaxy S25+ hardware testing remains pending.** Includes native Qwen3.5 4B GGUF inference (llama.cpp JNI, CPU-first) and Kokoro 82M `af_kore` at 1.5× using sherpa-onnx with Living Sigil PCM envelope animation. The app supports the full manual sermon workflow without either model or StickS3, and runs AI/TTS entirely on the phone once models are installed.

For installation and verification see [docs/m4-local-models.md](docs/m4-local-models.md).

To build with GitHub Actions run `.github/workflows/android-debug-apk.yml`; it fetches pinned third-party build dependencies and produces a debug APK artifact. Local builds first require `bash android/scripts/prepare-android-deps.sh`, Android SDK 36, NDK 28.2, CMake 3.22.1, Gradle 8.13 and JDK 17.

**Large model weights are not bundled:** import a Qwen3.5 4B Q4_K_M GGUF and the upstream Kokoro v1.0 tar.bz2 archive via Android's document picker. Private sermons are not sent to an external endpoint by default. AI outputs are unverified. The model integration has not yet been validated on the target phone.

# The Kingdom of Heaven — Pocket Scribe · M4 On-Device Qwen + Kokoro Alpha

**Primary target: Samsung Galaxy S25+ 12GB. No StickS3 is required.**

This package upgrades the earlier sermon workbench into a **native Android project whose essential manual functions run entirely on the phone**, with private SQLite storage, speech input when Android's on-device ASR is available, Android TTS fallback, backups, and an optional AI endpoint.

## Download and build

1. Open the included `android/` folder in Android Studio (SDK 36, Build Tools 35.0.0, Gradle 8.13, JDK 17).
2. Sync and build the **debug APK**, then install it on the Galaxy S25+.
3. Alternatively, use the included GitHub Actions workflow to build a downloadable debug APK on a GitHub-hosted runner.

See **[docs/mobile-alpha-testing.md](docs/mobile-alpha-testing.md)** for detailed build steps, verified tests, and the on-device test checklist. **This package contains the Android Studio project, not a prebuilt APK.**

## Phone-first features

- Create and edit sermon projects, with dates and passages.
- Capture, transcribe, edit, and organize notes on the phone (text entry always available).
- Maintain a scripture study notebook with URLs, citations, and research worksheets.
- Draft complete sermon outlines/manuscripts using reusable manual templates.
- Track rehearsal and delivery preparation.
- Search saved notes and drafts across sermons; export/import JSON archives; delete entries/projects.
- Read text aloud at a configurable speed using the installed Android speech engine.
- Keep the Living Sigil animations; independent state preview included.
- Configure an optional HTTPS/phone-loopback AI endpoint. AI is never required to take notes, research manually, write, or rehearse.

## What is not yet included

The **Kokoro `af_kore` voice model**, on-device Qwen model, offline scripture corpus, active web research connector, secure sync, StickS3 BLE, and at-rest encryption are **not bundled**. The current Android build integrates system TTS and an optional external or loopback model endpoint; it does not pretend that Kokoro or local LLM inference has been installed.

## Desktop development fallback (not needed on phone)

Run `python server/app.py` and open `http://127.0.0.1:8765/`. The Python development API exposes matching project/editor/archive operations. It stores data in `server/kingdom-local.sqlite3`, separately from the private Android DB.

Run regression tests:

```sh
python -m unittest discover -s tests -v
node --check web/app.js
```

## Original project content

The previous firmware prototype, audio-reactive visual demo, standalone source references, Kingdom legacy shell, and architectural documents remain in the package. The mobile app itself does not depend on any of the hardware pieces.

## Qwen import improvements (0.4.1)

See [docs/qwen-import-troubleshooting.md](docs/qwen-import-troubleshooting.md). Select the full 2.8 GB Q4_K_M `.gguf` from local Downloads; ensure at least ~4 GB free **after** the download. The import dialog now reports size, progress, and precise errors, and rejects mmproj/partial files before wasting time copying.
