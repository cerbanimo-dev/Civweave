from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'android/app/src/main/java/org/kingdom/pocketscribe/ModelInstaller.java').read_text()
ACTIVITY=(ROOT/'android/app/src/main/java/org/kingdom/pocketscribe/MainActivity.java').read_text()
WEB=(ROOT/'android/app/src/main/assets/app.js').read_text()

class ModelImporterContracts(unittest.TestCase):
    def test_importer_has_big_file_storage_checks(self):
        for token in ('getAvailableBytes()', 'OpenableColumns.SIZE', 'MIB', 'RESERVE', 'no space', 'Files.move', 'new File(base(),"qwen-import.partial")'):
            self.assertIn(token, JAVA)
    def test_gguf_validation(self):
        for token in ('name.endsWith(".gguf")','name.startsWith("mmproj-")','version!=3', "file.read()!='G'", 'done!=selected.bytes'):
            self.assertIn(token, JAVA)
    def test_progress_and_cleanup(self):
        for token in ('model-error', 'FLAG_KEEP_SCREEN_ON', 'finally {importingModel=false', 'model-progress'):
            self.assertIn(token, ACTIVITY)
        self.assertIn("case 'model-error'", WEB)

if __name__=='__main__': unittest.main()
