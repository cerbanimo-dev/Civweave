# Qwen GGUF installation on Galaxy S25+ — Mobile Alpha 0.4.1

The import button selects an **already downloaded** model file. It does not download the model.

Select `Qwen3.5-4B-Q4_K_M.gguf` from the **local Downloads** folder in Samsung My Files. The SoAIHQ Q4_K_M file is roughly **2.8 GB**; `mmproj-Qwen3.5-4B-f16.gguf` is an optional vision add-on and not the language model. A `.zip`, `.part`, `.crdownload`, `.html`, or incompletely downloaded file will fail installation.

The importer creates a second app-private copy before marking the model installed. After Kokoro and the source download, check **Samsung Settings → Battery and device care → Storage** and ensure at least **4 GB available**; allow more for the original download and temporary files. Keep the phone charged and the app **open/foreground** until the on-screen status says `Qwen3.5 GGUF installed`.

The updated importer checks available space and the selected document size before copying; displays progress in MiB and percent; rejects mmproj and incorrect extensions; validates GGUF magic and version 3; and cleans up a partial import on a handled error. It keeps the screen awake during imports, but does not have a long-running foreground service. If Android kills the app, an interrupted import needs to be restarted.

If it still fails, capture the precise **Model installation failed** message displayed in the model section. Relevant distinctions: download incomplete, insufficient storage, selected wrong file, provider access error, or error after copying during the model load (a separate issue).

## APK signing and preservation warning

This alpha was built with GitHub-hosted Android **debug signing**, for which the signing certificate changes between runners. A rebuilt APK **may not install over the old version** because of a signature mismatch. **Do not uninstall the working Kokoro installation or discard private sermon data just to test this importer**. First export any sermon projects. If the new debug APK cannot update in place, use the side-by-side import diagnostic application or wait for a stable, consistently signed build. An uninstall removes private model copies, including the successfully installed Kokoro pack.

No inference speed or device compatibility is claimed until tested on the Galaxy S25+.

The 0.4.1 build workflow produces two APKs: a normal one and a **side-by-side Import Test** package (`org.kingdom.pocketscribe.importtest`). Install the Import Test APK first to investigate Qwen safely without touching your existing Pocket Scribe database or Kokoro installation. This test package has its own isolated storage and requires its own model import. The normal 0.4.1 debug APK may require uninstalling the older debug-signed 0.4 APK; always export sermon projects first.
