package org.kingdom.pocketscribe;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.StatFs;
import android.provider.OpenableColumns;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Locale;

/** Import selected local model files. Models are private to this Android application. */
public final class ModelInstaller {
    public interface Progress { void update(String message); }
    private static final long MIB=1024L*1024L;
    private static final long MAX_GGUF=6_000_000_000L;
    private static final long MIN_GGUF=1_500_000_000L;
    private static final long RESERVE=384*MIB;
    private final Context context;
    public ModelInstaller(Context context){this.context=context.getApplicationContext();}
    public File base(){return new File(context.getFilesDir(),"models");}
    public File qwen(){return new File(base(),"qwen3.5-4b-q4_k_m.gguf");}
    public File kokoro(){return new File(base(),"kokoro-multi-lang-v1_0");}
    public boolean hasQwen(){return qwen().isFile() && qwen().length()>MIN_GGUF;}
    public boolean hasKokoro(){File d=kokoro();return new File(d,"model.onnx").isFile() && new File(d,"voices.bin").isFile() && new File(d,"tokens.txt").isFile() && new File(d,"espeak-ng-data").isDirectory() && new File(d,"lexicon-us-en.txt").isFile();}
    public static final class Selection {
        public final String filename;
        public final long bytes;
        Selection(String filename,long bytes){this.filename=filename;this.bytes=bytes;}
    }
    public Selection describe(Uri uri){
        String filename="Selected document";long bytes=-1;
        try(Cursor c=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){
            if(c!=null&&c.moveToFirst()){
                int name=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int size=c.getColumnIndex(OpenableColumns.SIZE);
                if(name>=0&&!c.isNull(name))filename=c.getString(name);
                if(size>=0&&!c.isNull(size))bytes=c.getLong(size);
            }
        }catch(Exception ignored){} // Some document providers do not supply metadata.
        return new Selection(filename==null?"Selected document":filename,bytes);
    }
    private long freeBytes(){return new StatFs(base().getAbsolutePath()).getAvailableBytes();}
    private static String size(long bytes){return String.format(Locale.US,"%.2f GiB",bytes/(1024.0*1024.0*1024.0));}
    public void importQwen(Uri uri,Progress progress) throws Exception {
        if(!base().isDirectory()&&!base().mkdirs())throw new IOException("Cannot create private model directory");
        // An interrupted import can leave a multi-gigabyte partial copy. Reclaim it BEFORE the free-space check.
        File temp=new File(base(),"qwen-import.partial");
        if(temp.exists()&&!temp.delete())throw new IOException("Could not clear interrupted Qwen import; free app storage or restart Pocket Scribe.");
        Selection selected=describe(uri);
        String name=selected.filename.toLowerCase(Locale.ROOT);
        if(!name.equals("selected document")&&!name.endsWith(".gguf"))
            throw new IOException("Selected "+selected.filename+". Choose the .gguf file, not a ZIP, HTML page or temporary download.");
        if(name.startsWith("mmproj-"))throw new IOException("That is the vision mmproj file. Select Qwen3.5-4B-Q4_K_M.gguf instead.");
        if(selected.bytes>=0&&(selected.bytes<MIN_GGUF||selected.bytes>MAX_GGUF))
            throw new IOException("Selected file is "+size(selected.bytes)+"; expected the complete Q4_K_M GGUF (about 2.8 GB). Check the download.");
        long needed=selected.bytes>0?selected.bytes:(3_200_000_000L);
        long free=freeBytes();
        if(free<needed+RESERVE)throw new IOException("Not enough free internal storage. Available "+size(free)+"; need roughly "+size(needed+RESERVE)+" for this import. The app makes a private copy of the downloaded GGUF.");
        progress.update("Checking storage ✓ · copying "+selected.filename+(selected.bytes>0?" ("+size(selected.bytes)+")":"")+"; keep the app open");
        long done=0,lastReport=0;
        try {
            try(InputStream in=context.getContentResolver().openInputStream(uri);
                FileOutputStream stream=new FileOutputStream(temp);
                OutputStream out=new BufferedOutputStream(stream,256*1024)){
                if(in==null)throw new IOException("Cannot read the selected document. Open it from local Downloads rather than a cloud provider.");
                byte[] buffer=new byte[256*1024];int n;
                while((n=in.read(buffer))!=-1){
                    if(n==0)continue;
                    out.write(buffer,0,n);done+=n;
                    if(done>MAX_GGUF)throw new IOException("GGUF is larger than 6 GB; select Q4_K_M, not Q8_0.");
                    if(done-lastReport>=8*MIB){
                        lastReport=done;
                        String part=selected.bytes>0?" ("+Math.min(99,(done*100/selected.bytes))+"%)":"";
                        progress.update("Importing Qwen: "+(done/MIB)+" MiB copied"+part+". Keep Pocket Scribe open.");
                    }
                }
                out.flush();stream.getFD().sync();
            }
            if(done<MIN_GGUF)throw new IOException("Import ended after "+size(done)+". The file is incomplete; download Qwen3.5-4B-Q4_K_M.gguf again.");
            if(selected.bytes>0&&done!=selected.bytes)throw new IOException("Import incomplete: selected file reports "+size(selected.bytes)+" but only "+size(done)+" was read.");
            try(RandomAccessFile file=new RandomAccessFile(temp,"r")){
                if(file.read()!='G'||file.read()!='G'||file.read()!='U'||file.read()!='F')
                    throw new IOException("Selected file is not GGUF (missing GGUF header). Download the actual model, not the website or ZIP.");
                int version=(file.read()&255)|((file.read()&255)<<8)|((file.read()&255)<<16)|((file.read()&255)<<24);
                if(version!=3)throw new IOException("Unsupported GGUF version "+version+" (expected version 3).");
            }
            progress.update("Copy complete ("+size(done)+"); finalizing model installation…");
            Files.move(temp.toPath(),qwen().toPath(),StandardCopyOption.REPLACE_EXISTING);
            if(!hasQwen())throw new IOException("The model could not be found after installation.");
            progress.update("Qwen3.5 GGUF installed ("+size(qwen().length())+"). Ready for an offline generation test.");
        }catch(Exception ex){
            temp.delete();
            if(ex instanceof IOException){
                String detail=ex.getMessage()==null?"Unknown storage error":ex.getMessage();
                if(detail.contains("ENOSPC")||detail.toLowerCase(Locale.ROOT).contains("no space"))
                    throw new IOException("Internal storage ran out during the GGUF copy. Free at least 4 GB, then retry.",ex);
            }
            throw ex;
        }
    }
    public void importKokoro(Uri uri,Progress progress) throws Exception {
        base().mkdirs();File stage=new File(base(),"kokoro-stage");delete(stage);stage.mkdirs();long extracted=0;int count=0;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("Cannot open Kokoro archive");
            try(TarArchiveInputStream tar=new TarArchiveInputStream(new BZip2CompressorInputStream(new BufferedInputStream(in)))){
                TarArchiveEntry entry;
                while((entry=tar.getNextTarEntry())!=null){
                    if(++count>3000)throw new IOException("Archive contains too many files");
                    String path=entry.getName().replace('\\','/');
                    int root=path.indexOf('/');if(root!=-1)path=path.substring(root+1);
                    if(path.isEmpty())continue;
                    if(path.startsWith("/")||path.contains("../")||path.equals("..")||entry.isSymbolicLink()||entry.isLink())throw new IOException("Unsafe archive path");
                    if(!(path.equals("model.onnx")||path.equals("voices.bin")||path.equals("tokens.txt")||path.equals("lexicon-us-en.txt")||path.startsWith("espeak-ng-data/")))continue;
                    File file=new File(stage,path);if(!file.getCanonicalPath().startsWith(stage.getCanonicalPath()+File.separator))throw new IOException("Unsafe archive location");
                    if(entry.isDirectory()){file.mkdirs();continue;}
                    if(!file.getParentFile().isDirectory()&&!file.getParentFile().mkdirs())throw new IOException("Cannot create model directory");
                    try(OutputStream out=new BufferedOutputStream(new FileOutputStream(file))){
                        byte[] buffer=new byte[64*1024];int n;
                        while((n=tar.read(buffer))!=-1){out.write(buffer,0,n);extracted+=n;if(extracted>1_500_000_000L)throw new IOException("Kokoro archive too large");}
                    }
                    if(count%20==0)progress.update("Kokoro extracted: "+count+" entries");
                }
            }
            if(!new File(stage,"model.onnx").isFile() || !new File(stage,"voices.bin").isFile() || !new File(stage,"tokens.txt").isFile() || !new File(stage,"lexicon-us-en.txt").isFile() || !new File(stage,"espeak-ng-data").isDirectory())throw new IOException("Not the expected kokoro-multi-lang-v1_0 model pack");
            File destination=kokoro(); delete(destination);
            Files.move(stage.toPath(),destination.toPath(),StandardCopyOption.REPLACE_EXISTING);
            progress.update("Kokoro af_kore voice pack installed");
        }catch(Exception e){delete(stage);throw e;}
    }
    private static void delete(File f){if(f.isDirectory()){File[] children=f.listFiles();if(children!=null)for(File c:children)delete(c);}f.delete();}
}
