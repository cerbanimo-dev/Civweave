'use strict';
const $=s=>document.querySelector(s);
const native=!!(window.PocketNative&&window.PocketNative.platform);
const state={projects:[],projectId:'',tab:'inbox',items:{notes:[],sources:[],drafts:[],tasks:[]},lastAnswer:'',projectEdit:false,entryId:'',aiConfig:{endpoint:'',model:'local',local_qwen:false,kokoro:false}};
const avatar={sequence:0,timer:null};
const tabs={inbox:{title:'Sermon Inbox',kind:'notes',desc:'Every idea stays in your private library until you decide to share it.'},study:{title:'Scripture Study',kind:'sources',desc:'Save passages, quotations, source URLs, cross-references, and competing interpretations.'},workshop:{title:'Sermon Workshop',kind:'drafts',desc:'Develop sermon outlines and manuscripts with independent versions.'},pulpit:{title:'Pulpit Studio',kind:'tasks',desc:'Prepare speaking notes, rehearsal tasks, and delivery checklists.'}};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const readable={idle:'Present',listening:'Listening',transcribing:'Transcribing',thinking:'Reflecting',researching:'Researching',writing:'Composing',speaking:'Speaking',saved:'Saved',error:'Connection issue',judgment:'Needs review'};
function setAvatar(mode){avatar.sequence++;clearTimeout(avatar.timer);window.LivingSigil?.setMode(mode);$('#sigil-label')?.setAttribute('aria-label','The Living Sigil: '+(readable[mode]||mode));if($('#sigil-state-text'))$('#sigil-state-text').textContent=readable[mode]||mode;}
function savePulse(){setAvatar('saved');const seq=avatar.sequence;avatar.timer=setTimeout(()=>{if(avatar.sequence===seq)setAvatar('idle');},1200);}
function toast(s){const el=$('#toast');el.textContent=s;el.classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('visible'),3500);}
function fail(e){toast(String(e.message||e));console.error(e);}
const pending=new Map();let nextId=0;
window.PocketMobile={
  reply(id,body,error){const job=pending.get(id);if(!job)return;pending.delete(id);if(error)job.reject(new Error(error));else try{job.resolve(JSON.parse(body))}catch(e){job.reject(new Error('Invalid mobile response: '+e.message))}},
  event(name,value){switch(name){
    case 'speech-state':setAvatar(value);break;
    case 'dictation-error':case 'voice-error':case 'file-error':setAvatar('judgment');toast(value);break;
    case 'voice-ready':if(!value.includes('unavailable'))$('#voice-pill').textContent='Android system voice · '+Number($('#speed').value).toFixed(1)+'×';break;
    case 'file-saved':toast(value);savePulse();break;
    case 'model-progress':$('#model-message').textContent=value;break;
    case 'model-error':$('#model-message').textContent=value;setAvatar('judgment');toast(value);break;
    case 'model-installed':$('#model-message').textContent=value;refreshRuntime().catch(fail);savePulse();toast(value);break;
    case 'voice-engine':$('#voice-engine').textContent=value;$('#voice-pill').textContent=value;break;
    case 'import-complete':state.projectId=value;localStorage.setItem('koh-active-project',value);refreshProjects().then(()=>{savePulse();toast('Sermon imported on this phone')}).catch(fail);break;
    default:break;
  }},
  dictation(target,value){const el=$('#'+target);if(el){el.value+=(el.value.trim()?' ':'')+value;el.dispatchEvent(new Event('input'));toast('Transcribed on device — review and save');savePulse();}}
};
async function api(path,options={}){
  const method=options.method||'GET';
  if(native){
    const key=String(++nextId);
    return new Promise((resolve,reject)=>{
      pending.set(key,{resolve,reject});
      window.PocketNative.requestAsync(key,method,path,options.body||'');
    });
  }
  const response=await fetch(path,{...options,headers:{'Content-Type':'application/json',...(options.headers||{})}});
  const data=await response.json().catch(()=>{throw new Error('Local server returned invalid JSON')});
  if(!response.ok)throw new Error(data.error||`HTTP ${response.status}`);
  return data;
}
const post=(path,o)=>api(path,{method:'POST',body:JSON.stringify(o)});
const put=(path,o)=>api(path,{method:'PUT',body:JSON.stringify(o)});
const del=path=>api(path,{method:'DELETE'});
const active=()=>state.projects.find(p=>p.id===state.projectId);
function requiredProject(){if(active())return true;toast('Create or select a sermon first');return false;}
async function refreshProjects(){
  state.projects=await api('/api/projects');
  const prior=localStorage.getItem('koh-active-project');
  if(!state.projects.some(p=>p.id===state.projectId))state.projectId=state.projects.some(p=>p.id===prior)?prior:(state.projects[0]?.id||'');
  $('#project').innerHTML='<option value="">Choose a sermon</option>'+state.projects.map(p=>`<option value="${esc(p.id)}">${esc(p.title)}</option>`).join('');
  $('#project').value=state.projectId;
  const p=active();$('#project-summary').textContent=p?`${p.passage||'No passage specified'} · ${p.occasion||'Occasion unset'}${p.due_date?' · '+p.due_date:''}`:'Create a sermon project to begin.';
  await refreshItems();
}
async function refreshItems(){
  if(!state.projectId){state.items={notes:[],sources:[],drafts:[],tasks:[]};render();return;}
  const rows=await Promise.all(['notes','sources','drafts','tasks'].map(kind=>api(`/api/${kind}?project_id=${encodeURIComponent(state.projectId)}`)));
  ['notes','sources','drafts','tasks'].forEach((kind,i)=>state.items[kind]=rows[i]);render();
}
function render(){
  const tab=tabs[state.tab],items=state.items[tab.kind];
  const buttons=active()?`<button id="add-entry" class="primary" type="button">+ New ${tab.kind.slice(0,-1)}</button>`:'';
  const extras=state.tab==='workshop'&&active()?`<button id="outline-template" class="secondary" type="button">Sermon outline template</button><button id="export" class="secondary" type="button">Export sermon</button>`:state.tab==='pulpit'&&active()?`<button id="rehearsal-template" class="secondary" type="button">Preparation checklist</button>`:state.tab==='study'&&active()?`<button id="study-template" class="secondary" type="button">Passage study worksheet</button>`:'';
  $('#workspace').innerHTML=`<div class="sectionhead"><h2>${tab.title}</h2><span class="badge">${items.length} entries</span></div><p>${tab.desc}</p><div class="toolbar">${buttons}${extras}</div>`+
    (items.length?items.map(item=>`<article class="entry"><h3>${esc(item.title)}</h3><div class="meta">${esc(item.created_at.slice(0,10))} · ${esc(item.provenance||'user')} ${item.status==='done'?'· Completed':''}</div>${item.url?`<a class="link" href="${esc(item.url)}" rel="noopener noreferrer">${esc(item.url)}</a>`:''}<p>${esc(item.body)}</p><div class="form-row"><button type="button" class="secondary mini" data-edit="${esc(item.id)}">Edit</button><button type="button" class="secondary mini" data-speak="${esc(item.id)}">Read</button><button type="button" class="secondary mini" data-remove="${esc(item.id)}">Delete</button></div></article>`).join(''):'<p class="empty">Nothing here yet. Begin with a question or observation.</p>');
  $('#add-entry')?.addEventListener('click',()=>openEntry(tab.kind));
  $('#export')?.addEventListener('click',exportProject);
  $('#outline-template')?.addEventListener('click',()=>openEntry('drafts',null,{
    title:'Sermon Outline — '+(active()?.passage||'Untitled'),
    body:'Central message:\n\nPassage and historical context:\n\nOpening illustration:\n\n1. First movement:\n\n2. Second movement:\n\n3. Third movement:\n\nApplication:\n\nConclusion / invitation:\n\nSources to verify:\n'}));
  $('#study-template')?.addEventListener('click',()=>openEntry('sources',null,{title:'Study worksheet — '+(active()?.passage||'Passage'),body:'Observation (what is stated):\n\nHistorical and literary context:\n\nTranslation questions:\n\nCross-references:\n\nInterpretive alternatives:\n\nCitation / evidence to check:\n'}));
  $('#rehearsal-template')?.addEventListener('click',()=>openEntry('tasks',null,{title:'Rehearsal checklist',body:'[ ] Confirm the primary point\n[ ] Verify quotations and citations\n[ ] Review transitions\n[ ] Time the delivery\n[ ] Practice the conclusion\n[ ] Prepare speaker notes\n'}));
  document.querySelectorAll('[data-edit]').forEach(btn=>btn.addEventListener('click',()=>openEntry(tab.kind,items.find(i=>i.id===btn.dataset.edit))));
  document.querySelectorAll('[data-speak]').forEach(btn=>btn.addEventListener('click',()=>readAloud(items.find(i=>i.id===btn.dataset.speak)?.body||'')));
  document.querySelectorAll('[data-remove]').forEach(btn=>btn.addEventListener('click',async()=>{
    if(!confirm('Delete this entry from this device? This cannot be undone.'))return;
    try{await del(`/api/${tab.kind}/${encodeURIComponent(btn.dataset.remove)}`);await refreshItems();savePulse();toast('Entry deleted')}catch(e){fail(e)}
  }));
}
function openEntry(kind,entry=null,defaults={}){
  if(!requiredProject())return;
  state.entryId=entry?.id||'';$('#editor-form').dataset.kind=kind;
  $('#editor-title').textContent=entry?'Edit '+kind.slice(0,-1):'New '+kind.slice(0,-1);
  $('#entry-title').value=entry?.title||defaults.title||'';
  $('#entry-body').value=entry?.body||defaults.body||'';
  $('#entry-url').value=entry?.url||'';
  $('#entry-url-label').hidden=kind!=='sources';
  $('#entry-status-label').hidden=kind!=='tasks';
  $('#entry-done').checked=entry?.status==='done';
  $('#editor').showModal();
}
async function exportProject(){
  if(!requiredProject())return;
  try{
    const data=await api(`/api/export?project_id=${encodeURIComponent(state.projectId)}`);
    const filename=`pocket-scribe-${state.projectId.slice(0,8)}.json`;
    if(native)window.PocketNative.createExport(JSON.stringify(data,null,2),filename);
    else download(JSON.stringify(data,null,2),filename);
  }catch(e){fail(e)}
}
function download(text,filename){
  const url=URL.createObjectURL(new Blob([text],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
}
function beginImport(){
  if(native){window.PocketNative.importArchive();return;}
  const picker=document.createElement('input');picker.type='file';picker.accept='.json,application/json';
  picker.onchange=async()=>{if(!picker.files?.[0])return;try{
    if(picker.files[0].size>3000000)throw new Error('Archive exceeds 3MB');
    const data=JSON.parse(await picker.files[0].text());const p=await post('/api/import',data);
    state.projectId=p.id;localStorage.setItem('koh-active-project',p.id);await refreshProjects();savePulse();toast('Archive imported');
  }catch(e){fail(e)}};
  picker.click();
}
function readAloud(text){if(!text.trim()){toast('Nothing to read yet');return}if(!native){toast('Read-aloud is available in the Android app');return}window.PocketNative.speak(text,Number($('#speed').value));}
function dictate(target){if(!native){toast('On-device dictation requires the Android app');return}window.PocketNative.dictate(target);}
async function search(){
  const q=$('#search').value.trim();const panel=$('#search-results');
  if(q.length<2){panel.textContent='Enter at least two characters';return;}
  try{const rows=await api('/api/search?q='+encodeURIComponent(q));
    panel.innerHTML=rows.length?rows.map(x=>`<article class="entry"><strong>${esc(x.title)}</strong><div class="meta">${esc(x.kind)}</div><p>${esc(x.excerpt||'')}</p><button class="secondary mini" data-result="${esc(x.project_id)}">Open sermon</button></article>`).join(''):'<p class="empty">No matching notes or drafts.</p>';
    panel.querySelectorAll('[data-result]').forEach(b=>b.addEventListener('click',()=>{state.projectId=b.dataset.result;localStorage.setItem('koh-active-project',state.projectId);refreshProjects().catch(fail)}));
  }catch(e){fail(e)}
}
async function refreshRuntime(){
  if(!native)return;
  const r=await api('/api/runtime');
  $('#model-state').textContent=r.qwen_installed&&r.kokoro_installed?'Both installed':r.qwen_installed?'Qwen ready':r.kokoro_installed?'Kokoro ready':'Install models';
  $('#voice-engine').textContent=r.voice;
  $('#voice-pill').textContent=r.voice;
  $('#ai-status').textContent=r.qwen_installed?'Local Qwen ready':state.aiConfig.endpoint?'Endpoint configured':'Model not installed';
  $('#model-message').textContent=(r.qwen_installed?'Qwen installed. ':'Qwen GGUF needed. ')+(r.kokoro_installed?'Kokoro af_kore installed.':'Kokoro voice pack needed.');
}
async function init(){
  try{
    const health=await api('/api/health');
    $('#status').textContent=native?'Standalone · saved on phone':'Local development web';
    $('#voice-engine').textContent=native?'Checking Kokoro voice pack':'Not available in browser';
    if(native)$('#voice-pill').textContent='Android system voice · '+Number($('#speed').value).toFixed(1)+'×';
    setAvatar('idle');await refreshProjects();
    try{state.aiConfig=await api('/api/config');$('#ai-endpoint').value=state.aiConfig.endpoint||'';$('#ai-model').value=state.aiConfig.model||'local';$('#ai-status').textContent=state.aiConfig.local_qwen?'Local Qwen ready':state.aiConfig.endpoint?'Endpoint configured':'No AI configured';}catch(e){console.warn('Config not supported:',e)}
    if(native)await refreshRuntime();
  }catch(e){$('#status').textContent='Storage unavailable';setAvatar('error');fail(e)}
}
$('#project').addEventListener('change',async e=>{state.projectId=e.target.value;localStorage.setItem('koh-active-project',state.projectId);await refreshProjects().catch(fail)});
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-tab]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');state.tab=b.dataset.tab;render()}));
$('#new-project').addEventListener('click',()=>{state.projectEdit=false;$('#project-dialog-title').textContent='New sermon project';$('#project-form').reset();$('#project-editor').showModal()});
$('#edit-project').addEventListener('click',()=>{if(!requiredProject())return;const p=active();state.projectEdit=true;$('#project-dialog-title').textContent='Edit sermon';$('#new-title').value=p.title;$('#new-passage').value=p.passage;$('#new-occasion').value=p.occasion;$('#new-date').value=p.due_date;$('#project-editor').showModal()});
$('#project-form').addEventListener('submit',async e=>{e.preventDefault();try{
  const values={title:$('#new-title').value,passage:$('#new-passage').value,occasion:$('#new-occasion').value,due_date:$('#new-date').value};
  const p=state.projectEdit?await put('/api/projects/'+encodeURIComponent(state.projectId),values):await post('/api/projects',values);
  state.projectId=p.id;localStorage.setItem('koh-active-project',p.id);$('#project-editor').close();await refreshProjects();savePulse();toast('Sermon saved on device');
}catch(err){fail(err)}});
$('#close-project').onclick=()=>$('#project-editor').close();
$('#quick-note').onclick=()=>openEntry('notes');
$('#voice-note').onclick=()=>{if(!requiredProject())return;openEntry('notes');dictate('entry-body')};
$('#import-project').onclick=beginImport;
$('#close-editor').onclick=()=>$('#editor').close();$('#cancel-editor').onclick=()=>$('#editor').close();
$('#editor-form').addEventListener('submit',async e=>{e.preventDefault();try{
  const kind=e.target.dataset.kind;
  const entry={project_id:state.projectId,title:$('#entry-title').value,body:$('#entry-body').value,url:kind==='sources'?$('#entry-url').value:'',status:$('#entry-done').checked?'done':'open'};
  if(state.entryId)await put(`/api/${kind}/${encodeURIComponent(state.entryId)}`,entry);else await post('/api/'+kind,entry);
  $('#editor').close();await refreshItems();savePulse();toast('Saved on phone');
}catch(err){fail(err)}});
$('#dictate-body').onclick=()=>dictate('entry-body');$('#read-body').onclick=()=>readAloud($('#entry-body').value);$('#stop-read').onclick=()=>{if(native)window.PocketNative.stopSpeaking();setAvatar('idle')};
$('#export-project-main').onclick=exportProject;
$('#delete-project').onclick=async()=>{if(!requiredProject())return;if(!confirm('Permanently delete the entire sermon and ALL its saved entries? Export first if you want a backup.'))return;try{await del('/api/projects/'+encodeURIComponent(state.projectId));state.projectId='';localStorage.removeItem('koh-active-project');await refreshProjects();savePulse();toast('Sermon deleted')}catch(e){fail(e)}};
$('#search-button').onclick=search;$('#search').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search()}});
$('#dictate-question').onclick=()=>dictate('question');
$('#ask-form').addEventListener('submit',async e=>{e.preventDefault();if(!requiredProject())return;
  if(!state.aiConfig.local_qwen&&!state.aiConfig.endpoint){toast('Import Qwen GGUF below or configure an endpoint.');return;}
  const remote=!state.aiConfig.local_qwen&&state.aiConfig.endpoint.startsWith('https://');
  const include=$('#share-context').checked;
  if(remote&&!confirm('Send this question'+(include?' and selected project notes':'')+' to the external AI service?'))return;
  const btn=$('#ask-button');btn.disabled=true;setAvatar('thinking');$('#answer').textContent=state.aiConfig.local_qwen?'Generating with on-device Qwen…':'Requesting the configured model…';
  try{const r=await post('/api/assist',{project_id:state.projectId,question:$('#question').value,include_context:include,remote_consent:remote});
    state.lastAnswer=r.answer;$('#answer').textContent=r.answer+'\n\n[Unverified AI draft. Verify sources and quotations.]';$('#save-answer').disabled=false;toast('Draft received — verify references');
  }catch(err){$('#answer').textContent=String(err.message||err);setAvatar('judgment');fail(err)}finally{btn.disabled=false;if(window.LivingSigil?.getState()==='thinking')setAvatar('idle')}
});
$('#save-answer').onclick=async()=>{if(!requiredProject()||!state.lastAnswer)return;try{await post('/api/notes',{project_id:state.projectId,title:'AI working note — requires verification',body:state.lastAnswer});await refreshItems();savePulse();toast('AI working draft saved')}catch(e){fail(e)}};
$('#speak-answer').onclick=()=>readAloud($('#answer').textContent);
$('#save-ai-config').onclick=async()=>{try{state.aiConfig=await post('/api/config',{endpoint:$('#ai-endpoint').value,model:$('#ai-model').value});$('#ai-status').textContent=state.aiConfig.endpoint?'Endpoint configured':'No AI configured';toast('Model endpoint saved') }catch(e){fail(e)}};
$('#install-qwen').onclick=()=>{if(!native){toast('Install from Android app');return}window.PocketNative.importModel('qwen')};
$('#install-kokoro').onclick=()=>{if(!native){toast('Install from Android app');return}window.PocketNative.importModel('kokoro')};
$('#clear-ai-config').onclick=async()=>{try{state.aiConfig=await post('/api/config',{endpoint:'',model:'local'});$('#ai-endpoint').value='';$('#ai-status').textContent='No AI configured';toast('AI endpoint disabled')}catch(e){fail(e)}};
$('#speed').addEventListener('input',e=>{const speed=Number(e.target.value).toFixed(1);$('#speed-display').textContent=speed+'×';localStorage.setItem('koh-voice-speed',speed);if(native)$('#voice-pill').textContent='Android system voice · '+speed+'×'});
const speed=Number(localStorage.getItem('koh-voice-speed'))||1.5;$('#speed').value=String(Math.min(2.5,Math.max(.8,speed)));$('#speed-display').textContent=Number($('#speed').value).toFixed(1)+'×';
init();
