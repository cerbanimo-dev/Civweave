"""Regression contracts for Android edge-to-edge display and offline model installer."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = ROOT / 'android/app/src/main/java/org/kingdom/pocketscribe'


class MobileSetupContract(unittest.TestCase):
    def test_native_insets_protect_system_bars_and_ime(self):
        src = (JAVA/'MainActivity.java').read_text()
        self.assertIn('setDecorFitsSystemWindows(false)', src)
        self.assertIn('WindowInsets.Type.systemBars()', src)
        self.assertIn('WindowInsets.Type.displayCutout()', src)
        self.assertIn('WindowInsets.Type.ime()', src)
        self.assertIn('view.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom))', src)
        self.assertIn('safeFrame.requestApplyInsets()', src)

    def test_user_initiates_download_and_can_pause(self):
        src = (JAVA/'MainActivity.java').read_text()
        web = (ROOT/'web/app.js').read_text()
        self.assertIn('@JavascriptInterface public void downloadModel(String kind)', src)
        self.assertIn('pauseModelDownload()', src)
        self.assertIn('cancelDownload.set(true)', src)
        self.assertIn("$('#download-qwen').onclick=()=>startModelDownload('qwen')",web)
        self.assertIn("$('#download-kokoro').onclick=()=>startModelDownload('kokoro')",web)
        self.assertNotIn("confirm('Download the Qwen model",web)
        self.assertNotIn("confirm('Download the Kokoro voice pack",web)
        self.assertIn("typeof window.PocketNative.downloadModel!=='function'",web)
        self.assertIn('window.PocketNative.downloadModel(kind)', web)
        self.assertIn('window.PocketNative.pauseModelDownload()', web)

    def test_dialog_fallback_and_storage_numbers(self):
        src = (JAVA/'MainActivity.java').read_text()
        self.assertIn('browser.setWebChromeClient(new WebChromeClient()',src)
        self.assertIn('result.confirm()',src)
        self.assertIn('result.cancel()',src)
        self.assertIn('.put("available_bytes",models.freeStorageBytes())',src)
        self.assertIn('.put("qwen_download_partial_bytes",models.qwenDownloadPartial().length())',src)

    def test_https_pinned_checksum_and_resume_range(self):
        src = (JAVA/'ModelDownload.java').read_text()
        self.assertIn('https://huggingface.co/SoAIHQ/Qwen3.5-4B-GGUF/resolve/main/Qwen3.5-4B-Q4_K_M.gguf', src)
        self.assertIn('2ebe6eb67cb92adeffc7073c48dd4e3baf79465ac650793dc751cad2b29cf219', src)
        self.assertIn('setRequestProperty("Range"', src)
        self.assertIn('Content-Range', src)
        self.assertIn('if(!url.getProtocol().equals("https"))', src)
        self.assertIn('sha256Check(temp,QWEN_SHA256', src)

    def test_storage_is_private_and_manual_import_remains(self):
        model = (JAVA/'ModelInstaller.java').read_text()
        self.assertIn('context.getFilesDir()', model)
        self.assertIn('qwen-download.partial', model)
        self.assertIn('public void importQwen(', model)
        html = (ROOT/'web/index.html').read_text()
        self.assertIn('id="install-qwen"',html)
        self.assertIn('id="install-kokoro"',html)
        self.assertIn('id="download-qwen"',html)

    def test_install_state_and_progress_visible_near_top(self):
        html = (ROOT/'web/index.html').read_text()
        self.assertLess(html.index('id="ai-setup"'),html.index('Current sermon'))
        for name in ('setup-badge','qwen-setup-status','kokoro-setup-status','model-progress-bar','pause-model'):
            self.assertIn(f'id="{name}"',html)
        self.assertIn('aria-live="polite"',html)

    def test_webview_has_no_unrestricted_external_page_access(self):
        src = (JAVA/'MainActivity.java').read_text()
        self.assertIn('settings.setBlockNetworkLoads(true)',src)
        self.assertIn('settings.setAllowUniversalAccessFromFileURLs(false)',src)
        self.assertIn('ModelDownload(models).downloadQwen',src)

    def test_android_packaged_files_mirror_web(self):
        for name in ('index.html','styles.css','app.js'):
            self.assertEqual((ROOT/'web'/name).read_bytes(),(ROOT/'android/app/src/main/assets'/name).read_bytes())


if __name__=='__main__':
    unittest.main()
