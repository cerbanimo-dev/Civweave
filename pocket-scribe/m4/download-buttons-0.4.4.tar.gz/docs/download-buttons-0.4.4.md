# Pocket Scribe 0.4.4 — Download buttons hotfix

## Root-cause hypothesis from source inspection

In Pocket Scribe 0.4.3, both model Download buttons called JavaScript `confirm()` before invoking the native Android downloader. The WebView did not set a `WebChromeClient` to handle JS dialogs, so some environments may suppress/cancel the confirmation, causing a click with no visible effect. This is a strong source-level explanation, not yet confirmed on the phone.

## Fix

* Clicking either labeled Download button directly starts the existing native downloader, with clear immediate status and disabling controls while active. It no longer calls `confirm()`.
* If the native bridge cannot be invoked, show a visible error and restore buttons.
* Register a restricted `WebChromeClient.onJsConfirm` for unrelated actions (delete sermon confirmation).
* Extend `/api/runtime` with actual internal storage availability and resumable Qwen partial byte count, replacing `NaN GiB` setup copy.
* Keep all existing model filenames, app IDs, private storage, and project DB unchanged. For cautious testing, use side-by-side APK suffix `.setup043` or a new `.setup044` suffix: these cannot access original models automatically.

## Device acceptance tests

1. Tap Download Qwen. The setup panel must immediately change to Starting Qwen, then display a network/storage progress message or a specific error. It must never do nothing.
2. Tap Pause. Buttons must become available after the installer emits a paused event. Tap Download again; it should resume if remote supports Range.
3. Tap Download Kokoro. It should show a starting state and progress or a useful error, without an additional confirmation dialog.
4. Confirm GB available is a number rather than NaN.
5. Attempt to delete a test sermon and verify a native confirmation dialog appears.
6. Test a network disconnect, insufficient storage, and a cancelled import, then ensure manual Import existing GGUF remains available.
7. Verify actual transfer of full Qwen/Kokoro weights on Galaxy S25+: **not verified by build/test suite**.
