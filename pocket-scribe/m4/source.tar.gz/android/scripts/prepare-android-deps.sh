#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p app/libs app/src/main/cpp/third_party
if [ ! -f app/libs/sherpa-onnx-1.13.8.aar ]; then
  curl --fail --location --retry 3 'https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-1.13.8.aar' -o app/libs/sherpa-onnx-1.13.8.aar
fi
printf '%s  %s\n' '633c24321e06b1fe79feafa03ea16cbc0f8a286641e2da3559bac91bdb13bd96' 'app/libs/sherpa-onnx-1.13.8.aar' | sha256sum --check --status
if [ ! -f app/src/main/cpp/third_party/llama.cpp/CMakeLists.txt ]; then
  git clone --depth 1 --branch v0.5.0 https://github.com/ggml-org/llama.cpp app/src/main/cpp/third_party/llama.cpp
fi
