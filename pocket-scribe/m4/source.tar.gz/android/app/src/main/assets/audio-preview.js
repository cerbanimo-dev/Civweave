/* Local-only audio preview, deliberately separate from Kokoro and BLE support. */
(() => {
  'use strict';
  const input=document.getElementById('sampleFile');
  const audio=document.getElementById('audioSource');
  if(!input||!audio||!window.LivingSigil||!window.SigilEnvelope)return;
  let objectUrl=null, ctx=null, analyser=null, samples=null, playing=false;
  input.addEventListener('change',()=>{
    if(objectUrl){URL.revokeObjectURL(objectUrl);objectUrl=null;}
    audio.pause();playing=false;window.LivingSigil.setVoiceLevel(0);
    const file=input.files && input.files[0];
    if(file){objectUrl=URL.createObjectURL(file);audio.src=objectUrl;audio.load();}
  });
  async function ensureGraph(){
    if(ctx)return;
    const AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)throw new Error('Browser AudioContext not available');
    ctx=new AC();analyser=ctx.createAnalyser();analyser.fftSize=2048;
    samples=new Float32Array(analyser.fftSize);
    const src=ctx.createMediaElementSource(audio);
    src.connect(analyser);analyser.connect(ctx.destination);
  }
  function tick(){
    if(!playing)return;
    // Analyser measures actual decoded output while the media element plays.
    analyser.getFloatTimeDomainData(samples);
    const intensity=SigilEnvelope.normalize(SigilEnvelope.rms(samples));
    LivingSigil.setVoiceLevel(intensity);
    requestAnimationFrame(tick);
  }
  audio.addEventListener('play',async()=>{
    try{
      await ensureGraph();await ctx.resume();
      LivingSigil.stopDemo();LivingSigil.setMode('speaking');
      if(!playing){playing=true;requestAnimationFrame(tick);}
    }catch(err){playing=false;audio.pause();console.warn('Audio preview failed',err);}
  });
  function finish(){playing=false;LivingSigil.setVoiceLevel(0);LivingSigil.setMode('idle');}
  audio.addEventListener('pause',finish);audio.addEventListener('ended',finish);
  window.addEventListener('pagehide',()=>{
    audio.pause();if(objectUrl)URL.revokeObjectURL(objectUrl);
    if(ctx)ctx.close();
  });
})();
