/* Pure, independently testable Living Sigil envelope tools.
 * Energy from actual PCM. Host must align events to playback clock before delivery.
 * Browser/WebView UMD; node:test compatible. No microphone or network access.
 */
(function(root,factory){
  if(typeof module==='object'&&module.exports) module.exports=factory();
  else root.SigilEnvelope=factory();
})(typeof globalThis==='object'?globalThis:this,function(){
  'use strict';
  const MODES=['idle','listening','transcribing','thinking','researching','writing','speaking','judgment','saved','error'];
  const clip=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
  function rms(samples){
    if(!samples||!samples.length)return 0;
    let sum=0,n=0;
    for(let i=0;i<samples.length;i++){
      const v=Number(samples[i]);if(!Number.isFinite(v))continue;
      sum+=v*v;n++;
    }
    return n?Math.sqrt(sum/n):0;
  }
  function normalize(level,noiseFloor=.012,reference=.25){
    if(!Number.isFinite(level)||level<=noiseFloor)return 0;
    return clip((level-noiseFloor)/(reference-noiseFloor),0,1);
  }
  function envelope(samples,rate,windowMs=32){
    if(!Number.isFinite(rate)||rate<=0)throw Error('Invalid PCM sample rate');
    if(!Number.isFinite(windowMs)||windowMs<10||windowMs>200)throw Error('Invalid window duration');
    const size=Math.max(1,Math.round(rate*windowMs/1000));
    let out=[];
    for(let start=0;start<samples.length;start+=size){
      const end=Math.min(samples.length,start+size);
      const value=normalize(rms(samples.subarray ? samples.subarray(start,end) : samples.slice(start,end)));
      out.push({playbackMs:Math.floor(start*1000/rate),level:value});
    }
    return out;
  }
  // 12-byte proposed visual packet; MUST travel only over authenticated, encrypted BLE.
  // It does not implement BLE pairing/transport or guarantee synchronization on its own.
  function encodePacket({seq=0,playbackMs=0,mode='speaking',energy=0,mic=0,onset=false}={}){
    const index=MODES.indexOf(mode);
    if(index<0)throw Error('Unknown sigil state');
    if(!Number.isInteger(seq)||seq<0||seq>65535)throw Error('Invalid sequence');
    if(!Number.isInteger(playbackMs)||playbackMs<0||playbackMs>0xffffffff)throw Error('Invalid playback timestamp');
    const data=new Uint8Array(12);const dv=new DataView(data.buffer);
    data[0]=0xa5;data[1]=1;data[2]=index;data[3]=onset?1:0;
    dv.setUint16(4,seq,true);dv.setUint32(6,playbackMs,true);
    data[10]=Math.round(clip(Number(energy)||0,0,1)*255);
    data[11]=Math.round(clip(Number(mic)||0,0,1)*255);
    return data;
  }
  function decodePacket(buf){
    const a=buf instanceof Uint8Array?buf:new Uint8Array(buf);
    if(a.length!==12||a[0]!==0xa5||a[1]!==1||a[3]&~1||!MODES[a[2]])throw Error('Invalid sigil packet');
    const dv=new DataView(a.buffer,a.byteOffset,a.byteLength);
    return {seq:dv.getUint16(4,true),playbackMs:dv.getUint32(6,true),mode:MODES[a[2]],onset:Boolean(a[3]&1),energy:a[10]/255,mic:a[11]/255};
  }
  return {MODES,rms,normalize,envelope,encodePacket,decodePacket};
});
