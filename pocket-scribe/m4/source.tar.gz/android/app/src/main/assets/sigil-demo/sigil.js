/* The Living Sigil — no dependencies, standalone canvas design prototype.
 * Actual speech sync: call setVoiceLevel(RMS[0..1]) from the audio playback clock.
 * Demo envelope in UI is synthetic and is NOT Kokoro playback.
 */
(() => {
  'use strict';
  const MODES = [
    {id:'idle',title:'PRESENT',label:'READY',subtitle:'A quiet moment before words.',name:'Resting presence',color:'#DFB36E',hint:'Breathing vesica, constant central light'},
    {id:'listening',title:'LISTENING',label:'SPEAK NOW',subtitle:'Receiving your words.',name:'Listening',color:'#71D8EB',hint:'Inward wavefronts follow microphone energy'},
    {id:'transcribing',title:'TRANSCRIBING',label:'CAPTURING WORDS',subtitle:'Giving your words a place.',name:'Transcribing',color:'#E6D2A3',hint:'Descending marks form a written spine'},
    {id:'thinking',title:'REFLECTING',label:'THINKING',subtitle:'Gathering the threads.',name:'Reflecting',color:'#B7A0ED',hint:'Seven nodes move through 3-1 cadence'},
    {id:'researching',title:'RESEARCHING',label:'FINDING SOURCES',subtitle:'Tracing sources and context.',name:'Researching',color:'#7AD6AB',hint:'A branching network lights on actual research milestones'},
    {id:'writing',title:'COMPOSING',label:'DRAFTING',subtitle:'Ideas finding their form.',name:'Composing',color:'#C9E7BD',hint:'Rosette petals settle into symmetry'},
    {id:'speaking',title:'SPEAKING',label:'SHARING',subtitle:'Words carried in light.',name:'Speaking',color:'#F8C475',hint:'Concentric rings follow playback audio RMS'},
    {id:'judgment',title:'NEEDS JUDGMENT',label:'YOUR DISCERNMENT',subtitle:'Your judgment matters.',name:'Needs judgment',color:'#EDA875',hint:'Unresolved node and an open, incomplete ring'},
    {id:'saved',title:'SAVED',label:'COMPLETE',subtitle:'Safe in your sermon notes.',name:'Saved (confirmation)',color:'#86D8AA',hint:'Temporary completion overlay, then return to rest'},
    {id:'error',title:'CONNECTION LOST',label:'RECONNECT',subtitle:'The connection needs care.',name:'Connection issue',color:'#F08D74',hint:'Stable disconnected state; do not simulate progress'}
  ];
  const $=s=>document.querySelector(s);
  const state = {mode:'idle',started:performance.now(),voiceLevel:0,smoothed:0,micLevel:.35,scale:1,playDemo:false,paused:false,reduced:window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches};
  const canvases = [$('#stickCanvas'),$('#phoneCanvas'),$('#sigilCanvas')].filter(Boolean);
  let transportConnected=false; // Never label the Stick as paired without an authenticated transport.
  const hexRGBA=(hex,a)=>{const n=parseInt(hex.slice(1),16);return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`};
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const smooth=(x)=>x*x*(3-2*x);
  const safeSin=(v)=>Math.sin(v);
  function glowing(ctx,x,y,r,color,strength=1){
    const grad=ctx.createRadialGradient(x,y,0,x,y,r);
    grad.addColorStop(0,hexRGBA('#FFF5D9',clamp(.86*strength,0,1)));
    grad.addColorStop(.22,hexRGBA(color,.65*strength));
    grad.addColorStop(.58,hexRGBA(color,.16*strength));
    grad.addColorStop(1,hexRGBA(color,0));
    ctx.fillStyle=grad;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
  }
  function path(ctx,points,color,width=1,alpha=1,close=false){
    if(!points.length)return;
    ctx.strokeStyle=hexRGBA(color,alpha);ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';
    ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);
    for(let i=1;i<points.length;i++) ctx.lineTo(points[i][0],points[i][1]);
    if(close)ctx.closePath();ctx.stroke();
  }
  function line(ctx,x1,y1,x2,y2,col,width=1,a=1){path(ctx,[[x1,y1],[x2,y2]],col,width,a)}
  function circle(ctx,x,y,r,col,width=1,a=1){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.strokeStyle=hexRGBA(col,a);ctx.lineWidth=width;ctx.stroke()}
  function arc(ctx,x,y,r,a,b,col,width=1,alpha=1){ctx.beginPath();ctx.arc(x,y,r,a,b);ctx.strokeStyle=hexRGBA(col,alpha);ctx.lineWidth=width;ctx.stroke()}
  function ellipse(ctx,x,y,rx,ry,col,w=1,a=1,rot=0){ctx.beginPath();ctx.ellipse(x,y,rx,ry,rot,0,Math.PI*2);ctx.strokeStyle=hexRGBA(col,a);ctx.lineWidth=w;ctx.stroke()}
  function node(ctx,x,y,r,col,lit=.5){glowing(ctx,x,y,9*lit,col,.5+lit/2);circle(ctx,x,y,r,col,1,.9);ctx.fillStyle=hexRGBA(col,.4+.6*lit);ctx.beginPath();ctx.arc(x,y,r*.5,0,Math.PI*2);ctx.fill()}
  function ring(ctx,r,col,opacity=1){circle(ctx,0,0,r,col,1,opacity)}
  function base(ctx,sec,color,rad=51,complex=false){
    const wave = state.reduced ? 0 : safeSin(sec*.48)*.5+.5;
    ring(ctx,rad,color,.21+wave*.09);
    ring(ctx,rad-6,color,.10+wave*.04);
    for(let i=0;i<12;i++){
      const a=i*Math.PI/6-Math.PI/2;
      const rr=rad+3;
      const sz=i%3===0?3:1.6;
      line(ctx,Math.cos(a)*rr,Math.sin(a)*rr,Math.cos(a)*(rr+sz),Math.sin(a)*(rr+sz),color,.7,.3);
    }
    // Continuity marker: every state retains the same central light.
    if(complex){ring(ctx,rad+7,color,.07);}
  }
  function vesica(ctx,t,color,level=0){
    const b=1+(state.reduced?0:Math.sin(t*.7)*.015)+level*.045;
    ellipse(ctx,-15,0,32*b,44*b,color,1.3,.83);
    ellipse(ctx,15,0,32*b,44*b,color,1.3,.83);
    const vert=[[0,-43],[0,43]];path(ctx,vert,color,.45,.29);
  }
  function star(ctx,rad,col,number=6,phase=0,alpha=.5){
    const pts=[];for(let i=0;i<number;i++){
      const a=(Math.PI*2*i/number)-Math.PI/2+phase;
      pts.push([rad*Math.cos(a),rad*Math.sin(a)]);
    }
    path(ctx,pts,col,1,alpha,true);
  }
  function drawGlyph(ctx,mode,t,level,large=false){
    const item=MODES.find(m=>m.id===mode)||MODES[0],col=item.color;
    ctx.save();
    base(ctx,t,col,52,large);
    switch(mode){
      case 'idle':{
        const breath=1+(state.reduced?0:.045*Math.sin(t*Math.PI/4.2));
        ctx.save();ctx.scale(breath,breath);vesica(ctx,t,col);
        ellipse(ctx,0,0,28,42,col,.6,.25);
        circle(ctx,0,0,13,col,.7,.35);
        ctx.restore();break;
      }
      case 'listening':{
        const v=clamp(state.micLevel,.05,1);
        vesica(ctx,t,col,v*.2);
        for(const side of [-1,1]){
          for(let j=0;j<3;j++){
            const p=(state.reduced?.25:(t* .75 +j/3)%1);
            const x=side*(51-33*p),ry=20+(1-p)*18;
            const intensity=.15+.55*(1-p)*v;
            ctx.beginPath();ctx.ellipse(x,0,8+6*p,ry,0,side<0?-Math.PI/2:Math.PI/2,side<0?Math.PI/2:Math.PI*1.5);
            ctx.strokeStyle=hexRGBA(col,intensity);ctx.lineWidth=1.3;ctx.stroke();
          }
        }
        circle(ctx,0,0,19+v*6,col,1.2,.16+v*.48);break;
      }
      case 'transcribing':{
        ellipse(ctx,0,0,33,42,col,1,.5);
        ellipse(ctx,0,0,21,33,col,.8,.4);
        line(ctx,0,-46,0,46,col,1.1,.7);
        for(let i=0;i<12;i++){
          let y=-42+i*7.5;
          let bright = state.reduced?.4:Math.pow(Math.max(0,1-Math.abs(((t*.55)%12)-i)/3),2);
          line(ctx,-(i%3===0?11:6),y,(i%3===0?11:6),y,col,1,.14+.72*bright);
          if(i%4===0)node(ctx,0,y,1.8,col,.25+bright*.7);
        }
        break;
      }
      case 'thinking':{
        const pulse=state.reduced?.25:Math.sin(t*Math.PI*2/3.4);
        const expand=1+.035*pulse;
        for(let i=0;i<3;i++){
          let a=(i*2*Math.PI/3-Math.PI/2);
          circle(ctx,23*Math.cos(a),23*Math.sin(a),31*expand,col,1,.68);
        }
        const pts=[];
        for(let i=0;i<7;i++){
          const a=i*Math.PI*2/7-Math.PI/2;
          pts.push([43*Math.cos(a),43*Math.sin(a)]);
        }
        path(ctx,pts,col,.65,.28,true);
        const active=Math.floor((t%3.4)/3.4*7);
        pts.forEach((p,i)=>node(ctx,p[0],p[1],2.4,col,state.reduced?.4:i===active?1:.22));
        break;
      }
      case 'researching':{
        const ps=[[0,-39],[-26,-25],[26,-25],[0,-12],[-31,3],[31,3],[0,14],[-22,29],[22,29],[0,42]];
        const edges=[[0,1],[0,2],[1,2],[1,3],[2,3],[1,4],[2,5],[3,4],[3,5],[3,6],[4,6],[5,6],[4,7],[5,8],[6,7],[6,8],[7,8],[7,9],[8,9]];
        for(let i=0;i<edges.length;i++){
          const e=edges[i];const v=state.reduced?.3:((t*.95+i/4)%3.1);
          const lit=v<.42 ? 1-v/.42:.12;
          line(ctx,ps[e[0]][0],ps[e[0]][1],ps[e[1]][0],ps[e[1]][1],col,.7,.22+.5*lit);
        }
        ps.forEach((p,i)=>node(ctx,p[0],p[1],3.2,col,state.reduced?.4:.3+.7*Math.max(0,1-Math.abs(i-((t*1.6)%10))/1.5)));
        break;
      }
      case 'writing':{
        const b=state.reduced?0:(1-Math.exp(-t*1.2));
        for(let i=0;i<6;i++){
          let a=i*Math.PI/3;
          ctx.save();ctx.rotate(a);
          ellipse(ctx,0,-22-(1-b)*5,21,31,col,.9,.67);
          ctx.restore();
        }
        star(ctx,40,col,6,0,.36);
        line(ctx,0,-46,0,46,col,.9,.5);
        line(ctx,-39,0,39,0,col,.9,.45);
        break;
      }
      case 'speaking':{
        const v=clamp(level,0,1);
        vesica(ctx,t,col,v);
        for(let i=0;i<4;i++){
          const p=state.reduced? i/4:(t*.24+i/4)%1;
          const r=12+p*41+v*4;
          circle(ctx,0,0,r,col,1+.8*v,(1-p)*(.23+.67*v));
        }
        circle(ctx,0,0,16+v*15,col,1,.45+v*.4);
        break;
      }
      case 'judgment':{
        for(let k=0;k<3;k++){
          const start=k*2*Math.PI/3+.12;
          arc(ctx,0,0,39,start,start+1.5,col,1,.5);
        }
        const ps=[];for(let i=0;i<7;i++){
          const a=i*Math.PI*2/7-Math.PI/2;ps.push([40*Math.cos(a),40*Math.sin(a)]);
        }
        path(ctx,[ps[0],ps[2],ps[4],ps[6]],col,1,.4);
        path(ctx,[ps[1],ps[3],ps[5],ps[0]],col,1,.33);
        ps.forEach((p,i)=>node(ctx,p[0],p[1],2.8,col,i===2?1:.28));
        glowing(ctx,ps[2][0],ps[2][1],20,col,.5);break;
      }
      case 'saved':{
        vesica(ctx,t,col);
        star(ctx,38,col,8,.4,.7);
        line(ctx,-17,0,-4,13,col,2.4,1);
        line(ctx,-4,13,23,-18,col,2.4,1);
        circle(ctx,0,0,28,col,.8,.48);
        break;
      }
      case 'error':{
        for(let i=0;i<4;i++)arc(ctx,0,0,42,i*1.58+.16,i*1.58+1.07,col,1.3,.7);
        line(ctx,-28,-28,28,28,col,1,.5);
        line(ctx,28,-28,-28,28,col,1,.3);
        node(ctx,0,0,4,col,.7);
        break;
      }
    }
    // Soft never-vanishing center. Its stability makes all modes feel like one identity.
    const luminous=mode==='speaking'?1+level*.4:1;
    glowing(ctx,0,0,17+6*(luminous-1),mode==='error'?'#F0A084':'#F6D69A',.78*luminous);
    ctx.fillStyle='#FFF0CB';ctx.beginPath();ctx.arc(0,0,2.7+level*1.1,0,Math.PI*2);ctx.fill();
    ctx.restore();
  }
  function drawDevice(ctx,t,mode,level){
    const info=MODES.find(m=>m.id===mode)||MODES[0];
    ctx.clearRect(0,0,135,240);
    const bg=ctx.createLinearGradient(0,0,135,240);bg.addColorStop(0,'#071319');bg.addColorStop(.55,'#071011');bg.addColorStop(1,'#050A0E');
    ctx.fillStyle=bg;ctx.fillRect(0,0,135,240);
    ctx.strokeStyle='#574930';ctx.lineWidth=.5;ctx.strokeRect(4.5,4.5,126,231);
    ctx.fillStyle='#BDA779';ctx.font='7px Georgia,serif';ctx.textAlign='center';ctx.fillText('THE KINGDOM',67.5,16);
    line(ctx,17,24,118,24,'#C8A66D',.65,.42);
    ctx.fillStyle='#EBDFC3';ctx.font='9px Georgia,serif';ctx.fillText('SUNDAY SERMON',67.5,39);
    ctx.fillStyle=info.color;ctx.font='bold 7.5px Arial,sans-serif';ctx.fillText(info.title,67.5,55);
    ctx.save();ctx.translate(67.5,125);drawGlyph(ctx,mode,t,level);ctx.restore();
    line(ctx,17,194,118,194,info.color,.7,.46);
    ctx.fillStyle=info.color;ctx.font='bold 8px Arial,sans-serif';ctx.fillText(info.label,67.5,210);
    ctx.fillStyle='#B1B5AC';ctx.font='6.7px Arial,sans-serif';ctx.fillText(mode==='error' ? 'POCKET SCRIBE  ·  OFFLINE' : transportConnected ? 'POCKET SCRIBE  ·  PAIRED' : 'POCKET SCRIBE  ·  UNPAIRED',67.5,225);
  }
  function drawPhone(ctx,t,mode,level){
    const info=MODES.find(m=>m.id===mode)||MODES[0];
    ctx.clearRect(0,0,360,610);
    const grad=ctx.createRadialGradient(180,285,20,180,285,420);grad.addColorStop(0,'#13211F');grad.addColorStop(.65,'#0A1619');grad.addColorStop(1,'#061014');
    ctx.fillStyle=grad;ctx.fillRect(0,0,360,610);
    ctx.strokeStyle=hexRGBA('#C4A873',.3);ctx.strokeRect(17,17,326,576);
    ctx.textAlign='center';ctx.fillStyle='#D9C391';ctx.font='10px Georgia,serif';ctx.fillText('THE KINGDOM OF HEAVEN',180,46);
    ctx.fillStyle='#EEE5CF';ctx.font='20px Georgia,serif';ctx.fillText('The Living Sigil',180,89);
    ctx.fillStyle=info.color;ctx.font='bold 11px Arial,sans-serif';ctx.fillText(info.title,180,121);
    ctx.save();ctx.translate(180,301);ctx.scale(2.18,2.18);drawGlyph(ctx,mode,t,level,true);ctx.restore();
    ctx.fillStyle='#EDE0BB';ctx.font='17px Georgia,serif';ctx.fillText(info.name,180,454);
    ctx.fillStyle='#B5BEAF';ctx.font='12px Arial,sans-serif';ctx.fillText(info.subtitle,180,485);
    line(ctx,46,519,314,519,info.color,.9,.45);
    ctx.fillStyle='#9AAEA5';ctx.font='11px Arial,sans-serif';ctx.fillText('SERMON WORKSHOP   ·   LOCAL COMPANION',180,552);
  }
  function drawCompact(ctx,t,mode,level){
    // Square, accessible workbench avatar: the same geometry without device chrome.
    ctx.clearRect(0,0,160,160);
    const bg=ctx.createRadialGradient(80,80,4,80,80,108);
    bg.addColorStop(0,'#152A27');bg.addColorStop(1,'#071219');
    ctx.fillStyle=bg;ctx.fillRect(0,0,160,160);
    ctx.save();ctx.translate(80,80);ctx.scale(1.24,1.24);
    drawGlyph(ctx,mode,t,level);ctx.restore();
  }
  function redraw(now){
    const sec=state.reduced?1:(now-state.started)/1000;
    const previous=state.smoothed;
    if(state.playDemo&&state.mode==='speaking'&&!state.reduced){
      // Explicitly synthetic demo rhythm. Production uses AudioTrack playback PCM RMS.
      const wave=Math.pow(Math.abs(Math.sin(sec*8.4)*Math.sin(sec*2.2)),1.3);
      state.voiceLevel=clamp(.09+.88*wave,0,1);
    }
    state.smoothed = state.reduced ? .25 : previous + (state.voiceLevel-previous)*(.29);
    for(const canvas of canvases){
      if(!canvas)continue;const isPhone=canvas.id==='phoneCanvas', isCompact=canvas.id==='sigilCanvas';
      const c=canvas.getContext('2d');
      c.save();const ratio=canvas.width/(isPhone?360:isCompact?160:135);c.scale(ratio,ratio);
      if(isPhone)drawPhone(c,sec,state.mode,state.smoothed);else if(isCompact)drawCompact(c,sec,state.mode,state.smoothed);else drawDevice(c,sec,state.mode,state.smoothed);
      c.restore();
    }
    if(!state.paused)requestAnimationFrame(redraw);
  }
  function switchMode(mode){
    if(!MODES.find(x=>x.id===mode))return;
    state.mode=mode;state.started=performance.now();
    const info=MODES.find(x=>x.id===mode);
    document.querySelectorAll('[data-mode]').forEach(b=>{
      const selected=b.getAttribute('data-mode')===mode;
      b.classList.toggle('selected',selected);b.setAttribute('aria-pressed',String(selected));
    });
    const status=$('#statusName');if(status)status.textContent=info.name;
    const detail=$('#statusHint');if(detail)detail.textContent=info.hint;
    const slider=$('#voiceLevel');if(slider)slider.disabled=mode!=='speaking';
    const demo=$('#demoAudio');if(demo)demo.disabled=mode!=='speaking';
  }
  function setVoiceLevel(value){state.voiceLevel=clamp(Number(value)||0,0,1);state.playDemo=false;const slider=$('#voiceLevel');if(slider)slider.value=String(Math.round(state.voiceLevel*100));}
  function setMicLevel(value){state.micLevel=clamp(Number(value)||0,0,1);}
  // Dev integration: consume PCM speech playback frames with real-time playback timestamps.
  // For a device, quantize envelope to uint8 and send timestamps ahead of audio on BLE.
  function pushPcmSamples(samples){
    let sum=0;for(let i=0;i<samples.length;i++)sum+=samples[i]*samples[i];
    const rms=Math.sqrt(sum/Math.max(1,samples.length));
    const normalized=clamp((rms-.012)/.25,0,1);
    setVoiceLevel(normalized);return normalized;
  }
  window.LivingSigil={setMode:switchMode,setVoiceLevel,setMicLevel,pushPcmSamples,getState:()=>state.mode, setTransportConnected(value){transportConnected=value===true;}, stopDemo(){state.playDemo=false;}};
  const initial= new URLSearchParams(location.search).get('state')||'idle';
  const controls=$('#states');
  if(controls){
    for(const item of MODES){
      const btn=document.createElement('button');btn.type='button';btn.dataset.mode=item.id;
      btn.textContent=item.name;btn.setAttribute('aria-pressed','false');
      btn.addEventListener('click',()=>switchMode(item.id));controls.appendChild(btn);
    }
  }
  const voice=$('#voiceLevel');if(voice)voice.addEventListener('input',e=>setVoiceLevel(e.target.value/100));
  const mic=$('#micLevel');if(mic)mic.addEventListener('input',e=>setMicLevel(e.target.value/100));
  const demo=$('#demoAudio');if(demo)demo.addEventListener('click',()=>{state.playDemo=!state.playDemo;demo.textContent=state.playDemo?'Stop envelope demo':'Play envelope demo';});
  switchMode(initial);
  if(voice)voice.disabled=state.mode!=='speaking';
  requestAnimationFrame(redraw);
})();
