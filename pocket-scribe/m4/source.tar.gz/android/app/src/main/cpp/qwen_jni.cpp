#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <cstring>
#include "llama.h"

namespace {
std::mutex inference_lock;
struct Utf { JNIEnv* env; jstring source; const char* ptr; Utf(JNIEnv* e,jstring s):env(e),source(s),ptr(e->GetStringUTFChars(s,nullptr)){} ~Utf(){if(ptr)env->ReleaseStringUTFChars(source,ptr);} };
void fail(JNIEnv* env,const char* message){jclass c=env->FindClass("java/lang/IllegalStateException"); if(c)env->ThrowNew(c,message);}
}

extern "C" JNIEXPORT jstring JNICALL
Java_org_kingdom_pocketscribe_QwenRuntime_inferNative(JNIEnv* env,jclass,jstring model_name,jstring user_prompt,jint max_output){
  if(!model_name || !user_prompt){fail(env,"Missing model or prompt");return nullptr;}
  std::lock_guard<std::mutex> guard(inference_lock);
  Utf path(env,model_name), prompt(env,user_prompt);
  if(!path.ptr || !prompt.ptr)return nullptr;
  llama_backend_init();
  auto mp=llama_model_default_params();
  mp.n_gpu_layers=0; // Portable on-device CPU first; no GPU assumptions.
  llama_model* model=llama_model_load_from_file(path.ptr,mp);
  if(!model){fail(env,"Qwen GGUF could not be loaded; check architecture, free memory and model file");return nullptr;}
  auto vocab=llama_model_get_vocab(model);
  auto cp=llama_context_default_params();
  cp.n_ctx=4096;cp.n_batch=256;cp.n_ubatch=256;cp.n_threads=4;cp.n_threads_batch=4;
  llama_context* ctx=llama_init_from_model(model,cp);
  if(!ctx){llama_model_free(model);fail(env,"Could not create Qwen inference context");return nullptr;}
  int needed=llama_tokenize(vocab,prompt.ptr,(int)strlen(prompt.ptr),nullptr,0,true,true);
  if(needed>=0 || -needed>3400){llama_free(ctx);llama_model_free(model);fail(env,"Model prompt is too long");return nullptr;}
  std::vector<llama_token> tokens(-needed);
  if(llama_tokenize(vocab,prompt.ptr,(int)strlen(prompt.ptr),tokens.data(),(int)tokens.size(),true,true)<0){llama_free(ctx);llama_model_free(model);fail(env,"Could not tokenize the Qwen prompt");return nullptr;}
  llama_batch batch=llama_batch_init(256,0,1);
  int pos=0;
  bool error=false;
  for(size_t off=0;off<tokens.size();off+=256){
    int count=(int)std::min((size_t)256,tokens.size()-off);
    batch.n_tokens=count;
    for(int i=0;i<count;i++){
      batch.token[i]=tokens[off+i]; batch.pos[i]=pos+i;
      batch.n_seq_id[i]=1;batch.seq_id[i][0]=0;
      batch.logits[i]=(off+i+1==tokens.size())?1:0;
    }
    if(llama_decode(ctx,batch)!=0){error=true;break;} pos+=count;
  }
  auto params=llama_sampler_chain_default_params();
  llama_sampler* sampler=llama_sampler_chain_init(params);
  llama_sampler_chain_add(sampler,llama_sampler_init_temp(0.65f));
  llama_sampler_chain_add(sampler,llama_sampler_init_dist(42));
  std::string answer;
  int limit=std::min(768,std::max(16,(int)max_output));
  for(int i=0;!error && i<limit && pos<4094;i++){
    llama_token next=llama_sampler_sample(sampler,ctx,-1);
    if(llama_vocab_is_eog(vocab,next)) break;
    int n=llama_token_to_piece(vocab,next,nullptr,0,0,true);
    if(n<0){ std::string piece((size_t)-n,'\0');
      int written=llama_token_to_piece(vocab,next,piece.data(),(int)piece.size(),0,true);
      if(written>0)answer.append(piece.data(),written);
    }else if(n>0){std::string piece((size_t)n,'\0');int written=llama_token_to_piece(vocab,next,piece.data(),n,0,true);if(written>0)answer.append(piece.data(),written);}
    batch.n_tokens=1;batch.token[0]=next;batch.pos[0]=pos++;
    batch.n_seq_id[0]=1;batch.seq_id[0][0]=0;batch.logits[0]=1;
    if(llama_decode(ctx,batch)!=0) error=true;
  }
  llama_sampler_free(sampler);llama_batch_free(batch);llama_free(ctx);llama_model_free(model);
  if(error){fail(env,"On-device Qwen inference failed");return nullptr;}
  return env->NewStringUTF(answer.c_str());
}
