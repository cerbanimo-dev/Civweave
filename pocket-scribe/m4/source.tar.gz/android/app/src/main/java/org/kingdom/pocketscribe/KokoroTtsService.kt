// REFERENCE NATIVE INTEGRATION ONLY — NOT COMPILED INTO DEVELOPER WEBVIEW SHELL.
// Requires the matching sherpa-onnx Android AAR, JNI and installed Kokoro model files.
// New milestone: animation envelopes FOLLOW AudioTrack's actual playback head, not synthesis time.
package org.kingdom.pocketscribe

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.min
import kotlin.math.sqrt

/** These pulses are derived from PCM *actually reached by the output playback head*.
 *  The phone renderer consumes onPulse directly; bonded BLE transport is a separate module.
 *  Callbacks run on worker threads and must be posted to Android UI thread if appropriate.
 */
data class SigilPulse(val sequence: Int, val playbackMs: Long, val energy: Float)

class KokoroTtsService(private val directory: File) {
    private val synthWorker=Executors.newSingleThreadExecutor()
    private val pulseWorker=Executors.newSingleThreadExecutor()
    private val generation=AtomicInteger(0)
    @Volatile private var tts: OfflineTts? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile var onPulse: ((SigilPulse)->Unit)? = null
    @Volatile var onPlaybackState: ((String)->Unit)? = null

    fun initialize() {
        require(File(directory,"model.onnx").exists()) { "Kokoro model is not installed" }
        require(File(directory,"voices.bin").exists()) { "Kokoro voice pack is not installed" }
        val model=OfflineTtsKokoroModelConfig(
            model=File(directory,"model.onnx").absolutePath,
            voices=File(directory,"voices.bin").absolutePath,
            tokens=File(directory,"tokens.txt").absolutePath,
            dataDir=File(directory,"espeak-ng-data").absolutePath,
            lexicon=File(directory,"lexicon-us-en.txt").absolutePath
        )
        tts=OfflineTts(config=OfflineTtsConfig(
            model=OfflineTtsModelConfig(kokoro=model,numThreads=4)))
    }

    /** Generate the selected voice `af_kore`, speed 1.5x, no pitch-shift playback hack. */
    fun speak(text: String) {
        stop()
        val session=generation.get()
        synthWorker.execute {
            val engine=tts ?: run { onPlaybackState?.invoke("error");return@execute }
            onPlaybackState?.invoke("synthesizing")
            try {
                val generated=engine.generate(text=text.take(3000),sid=5,speed=1.5f)
                if(session!=generation.get())return@execute
                val rate=generated.sampleRate
                require(rate>0) {"Invalid Kokoro sample rate"}
                val floats=generated.samples
                if(floats.isEmpty()){onPlaybackState?.invoke("idle");return@execute}
                val pcm=ShortArray(floats.size){idx ->
                    (floats[idx].coerceIn(-1f,1f)*32767).toInt().toShort()
                }
                val windowSize=(rate*32/1000).coerceAtLeast(1)
                val energy=FloatArray((pcm.size+windowSize-1)/windowSize){window ->
                    val start=window*windowSize
                    val end=min(pcm.size,start+windowSize)
                    var squareSum=0.0
                    for(i in start until end){ val x=pcm[i]/32768.0;squareSum+=x*x }
                    val rms=sqrt(squareSum/(end-start).coerceAtLeast(1))
                    ((rms-0.012)/0.238).coerceIn(0.0,1.0).toFloat()
                }
                val minBytes=AudioTrack.getMinBufferSize(rate,
                    AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)
                require(minBytes>0){"AudioTrack playback buffer unsupported"}
                val audio=AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(maxOf(minBytes,rate/4*2))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                if(session!=generation.get()){audio.release();return@execute}
                track=audio
                audio.play()
                onPlaybackState?.invoke("speaking")
                pulseWorker.execute {
                    var lastWindow=-1
                    var sequence=0
                    try {
                        while(session==generation.get()){
                            val head=audio.playbackHeadPosition.toLong() and 0xffffffffL
                            val index=(head/windowSize).toInt().coerceIn(0,energy.lastIndex)
                            if(index!=lastWindow){
                                lastWindow=index
                                onPulse?.invoke(SigilPulse(sequence++ and 0xffff,head*1000/rate,energy[index]))
                            }
                            if(head>=pcm.size)break
                            SystemClock.sleep(18)
                        }
                    }catch (_:IllegalStateException){ /* explicit cancellation raced with release */ }
                }
                var written=0
                while(written<pcm.size && session==generation.get()){
                    val count=min(2048,pcm.size-written)
                    val n=audio.write(pcm,written,count,AudioTrack.WRITE_BLOCKING)
                    if(n<=0)throw IllegalStateException("PCM playback write failed: $n")
                    written+=n
                }
                // Wait until queued audio has really played: completion != final write.
                val maxWait=SystemClock.elapsedRealtime()+((pcm.size.toLong()*1000/rate)+2000)
                while(session==generation.get() && SystemClock.elapsedRealtime()<maxWait){
                    val head=audio.playbackHeadPosition.toLong() and 0xffffffffL
                    if(head>=pcm.size)break
                    SystemClock.sleep(20)
                }
                if(session==generation.get())onPlaybackState?.invoke("idle")
            }catch(e:Exception){
                if(session==generation.get())onPlaybackState?.invoke("error")
            }finally{
                if(session==generation.get()){
                    val old=track;track=null
                    try{old?.stop()}catch (_:IllegalStateException){}
                    old?.release()
                }
            }
        }
    }
    fun stop(){
        generation.incrementAndGet()
        val old=track;track=null
        try{old?.pause();old?.flush()}catch (_:IllegalStateException){}
        old?.release()
        onPulse?.invoke(SigilPulse(0,0,0f))
    }
    fun close(){stop();tts?.release();tts=null;synthWorker.shutdownNow();pulseWorker.shutdownNow()}
}
