package org.kingdom.pocketscribe;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import java.util.UUID;
import java.time.Instant;

/** Private on-device SQLite store. No backend, login or accessory is necessary. */
final class NativeStore extends SQLiteOpenHelper {
    NativeStore(Context context) { super(context, "kingdom-pocketscribe.db", null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE projects(id TEXT PRIMARY KEY,title TEXT NOT NULL,passage TEXT NOT NULL DEFAULT '',occasion TEXT NOT NULL DEFAULT '',due_date TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE items(id TEXT PRIMARY KEY,project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,kind TEXT NOT NULL,title TEXT NOT NULL,body TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',provenance TEXT NOT NULL DEFAULT 'user',status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        db.execSQL("CREATE INDEX project_items ON items(project_id,kind)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){ throw new IllegalStateException("Migration required"); }
    @Override public void onConfigure(SQLiteDatabase db){ super.onConfigure(db);db.setForeignKeyConstraintsEnabled(true); }
    private static String stamp(){return Instant.now().toString();}
    private static String id(){return UUID.randomUUID().toString();}
    private static String limited(JSONObject o,String field,int max) throws JSONException {
        String s=o.optString(field, "");
        if(s.length()>max) throw new IllegalArgumentException(field+" exceeds "+max+" characters");
        return s;
    }
    private static String required(JSONObject o,String field,int max) throws JSONException {
        String s=limited(o,field,max).trim();
        if(s.isEmpty())throw new IllegalArgumentException(field+" is required");
        return s;
    }
    private static String sourceUrl(JSONObject o) throws JSONException {
        String s=limited(o,"url",2048).trim();
        if(!s.isEmpty() && !(s.startsWith("https://")||s.startsWith("http://")))throw new IllegalArgumentException("Use an HTTP(S) source URL");
        return s;
    }
    private static boolean validKind(String k){return k.equals("notes")||k.equals("sources")||k.equals("drafts")||k.equals("tasks");}
    private static JSONObject obj(Cursor c) throws JSONException {
        JSONObject o=new JSONObject();
        for(int i=0;i<c.getColumnCount();i++)o.put(c.getColumnName(i),c.getString(i));
        return o;
    }
    private static JSONArray list(SQLiteDatabase db,String sql,String...args) throws JSONException {
        JSONArray rows=new JSONArray();
        try(Cursor c=db.rawQuery(sql,args)){while(c.moveToNext())rows.put(obj(c));}
        return rows;
    }
    private static JSONObject first(SQLiteDatabase db,String sql,String...args) throws JSONException {
        try(Cursor c=db.rawQuery(sql,args)){return c.moveToFirst()?obj(c):null;}
    }
    private static void run(SQLiteDatabase db,String sql,Object...args){db.execSQL(sql,args);}
    private static JSONObject insertProject(SQLiteDatabase db,JSONObject data) throws JSONException {
        String key=id(),title=required(data,"title",200),created=stamp();
        run(db,"INSERT INTO projects(id,title,passage,occasion,due_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",key,title,limited(data,"passage",500),limited(data,"occasion",200),limited(data,"due_date",32),created,created);
        return first(db,"SELECT * FROM projects WHERE id=?",key);
    }
    private static JSONObject insertItem(SQLiteDatabase db,String kind,JSONObject data,String provenance) throws JSONException {
        if(!validKind(kind))throw new IllegalArgumentException("Unknown item kind");
        String project=required(data,"project_id",100),title=required(data,"title",300),key=id(),created=stamp();
        if(first(db,"SELECT id FROM projects WHERE id=?",project)==null)throw new IllegalArgumentException("Choose an existing sermon");
        run(db,"INSERT INTO items(id,project_id,kind,title,body,url,provenance,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            key,project,kind,title,limited(data,"body",120000),sourceUrl(data),provenance,"open",created,created);
        return first(db,"SELECT * FROM items WHERE id=?",key);
    }
    synchronized Object dispatch(String method,String fullPath,JSONObject input) throws JSONException {
        SQLiteDatabase db=getWritableDatabase();
        String path=fullPath.split("\\?",2)[0],qs=fullPath.contains("?")?fullPath.substring(fullPath.indexOf('?')+1):"";
        String[] chunks=path.split("/");
        if("GET".equals(method)&&path.equals("/api/health"))return new JSONObject().put("ok",true).put("stack","Android private SQLite").put("offline",true).put("stick_required",false).put("voice",new JSONObject().put("engine","Android system TTS fallback").put("kokoro_installed",false));
        if("GET".equals(method)&&path.equals("/api/projects"))return list(db,"SELECT * FROM projects ORDER BY updated_at DESC");
        if("POST".equals(method)&&path.equals("/api/projects"))return insertProject(db,input);
        if(chunks.length==4 && "api".equals(chunks[1])&&"projects".equals(chunks[2])){
            String key=chunks[3];
            if("PUT".equals(method)){
                if(first(db,"SELECT id FROM projects WHERE id=?",key)==null)throw new IllegalArgumentException("Sermon not found");
                run(db,"UPDATE projects SET title=?,passage=?,occasion=?,due_date=?,updated_at=? WHERE id=?",
                    required(input,"title",200),limited(input,"passage",500),limited(input,"occasion",200),limited(input,"due_date",32),stamp(),key);
                return first(db,"SELECT * FROM projects WHERE id=?",key);
            }
            if("DELETE".equals(method)){
                run(db,"DELETE FROM projects WHERE id=?",key);
                return new JSONObject().put("deleted",true);
            }
        }
        if("GET".equals(method)&&path.equals("/api/search")){
            String query=android.net.Uri.decode(getParam(qs,"q")).trim();
            if(query.length()<2)return new JSONArray();
            String like="%"+query.replace("\\","\\\\").replace("%","\\%").replace("_","\\_")+"%";
            return list(db,"SELECT id,project_id,kind,title,substr(body,1,180) AS excerpt FROM items WHERE title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT 80",like,like);
        }
        if("GET".equals(method)&&path.equals("/api/export")){
            String project=android.net.Uri.decode(getParam(qs,"project_id"));
            JSONObject p=first(db,"SELECT * FROM projects WHERE id=?",project);
            if(p==null)throw new IllegalArgumentException("Project not found");
            return new JSONObject().put("schema","kingdom.sermon-project.v1").put("project",p)
                .put("items",list(db,"SELECT * FROM items WHERE project_id=? ORDER BY created_at",project))
                .put("exported_at",stamp()).put("private",true)
                .put("federation",new JSONObject().put("shared",false).put("consent",JSONObject.NULL));
        }
        if("POST".equals(method)&&path.equals("/api/import")){
            if(!"kingdom.sermon-project.v1".equals(input.optString("schema")))throw new IllegalArgumentException("Unsupported archive schema");
            JSONObject p=input.getJSONObject("project");JSONArray items=input.getJSONArray("items");
            if(items.length()>300)throw new IllegalArgumentException("Archive contains too many entries");
            db.beginTransaction();
            try {
                JSONObject imported=insertProject(db,p);
                for(int i=0;i<items.length();i++){
                    JSONObject old=items.getJSONObject(i);
                    String kind=old.getString("kind");
                    JSONObject clean=new JSONObject().put("project_id",imported.getString("id"))
                        .put("title",old.getString("title")).put("body",old.optString("body",""))
                        .put("url",old.optString("url",""));
                    insertItem(db,kind,clean,"import");
                }
                db.setTransactionSuccessful();return imported;
            } finally {db.endTransaction();}
        }
        if(chunks.length>=3&&"api".equals(chunks[1])&&validKind(chunks[2])){
            String kind=chunks[2];
            if(chunks.length==3){
                if("GET".equals(method))return list(db,"SELECT * FROM items WHERE kind=? AND project_id=? ORDER BY created_at DESC",kind,android.net.Uri.decode(getParam(qs,"project_id")));
                if("POST".equals(method))return insertItem(db,kind,input,"user");
            }
            if(chunks.length==4){
                String key=chunks[3];
                if("PUT".equals(method)){
                    if(first(db,"SELECT id FROM items WHERE id=? AND kind=?",key,kind)==null)throw new IllegalArgumentException("Entry not found");
                    run(db,"UPDATE items SET title=?,body=?,url=?,status=?,updated_at=? WHERE id=? AND kind=?",required(input,"title",300),limited(input,"body",120000),sourceUrl(input),"done".equals(input.optString("status"))?"done":"open",stamp(),key,kind);
                    return first(db,"SELECT * FROM items WHERE id=?",key);
                }
                if("DELETE".equals(method)){
                    run(db,"DELETE FROM items WHERE id=? AND kind=?",key,kind);
                    return new JSONObject().put("deleted",true);
                }
            }
        }
        throw new IllegalArgumentException("Unsupported local request: "+method+" "+path);
    }
    private static String getParam(String query,String key){
        for(String pair:query.split("&")){
            int pivot=pair.indexOf('=');if(pivot>0&&pair.substring(0,pivot).equals(key))return pair.substring(pivot+1);
        }
        return "";
    }
}
