package org.kingdom.pocketscribe;

import android.content.Context;
import android.net.Uri;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/** Import user-selected on-device model data. No model weights are shipped in the APK. */
public final class ModelInstaller {
    public interface Progress { void update(String message); }
    private final Context context;
    public ModelInstaller(Context context){this.context=context.getApplicationContext();}
    public File base(){return new File(context.getFilesDir(),"models");}
    public File qwen(){return new File(base(),"qwen3.5-4b-q4_k_m.gguf");}
    public File kokoro(){return new File(base(),"kokoro-multi-lang-v1_0");}
    public boolean hasQwen(){return qwen().isFile() && qwen().length()>1_500_000_000L;}
    public boolean hasKokoro(){File d=kokoro();return new File(d,"model.onnx").isFile() && new File(d,"voices.bin").isFile() && new File(d,"tokens.txt").isFile() && new File(d,"espeak-ng-data").isDirectory() && new File(d,"lexicon-us-en.txt").isFile();}
    public void importQwen(Uri uri,Progress progress) throws Exception {
        base().mkdirs();File temp=new File(base(),"qwen-import.partial");long done=0;
        try(InputStream in=context.getContentResolver().openInputStream(uri);OutputStream out=new BufferedOutputStream(new FileOutputStream(temp))){
            if(in==null)throw new IOException("Cannot access the selected GGUF");
            byte[] buffer=new byte[128*1024];int n;
            while((n=in.read(buffer))!=-1){out.write(buffer,0,n);done+=n;if(done>6_000_000_000L)throw new IOException("GGUF exceeds allowed size");if(done % (16L*1024*1024)<n)progress.update("Qwen copied: "+(done/1048576)+" MiB");}
        }catch(Exception e){temp.delete();throw e;}
        try(RandomAccessFile f=new RandomAccessFile(temp,"r")){
            if(temp.length()<1_500_000_000L)throw new IOException("GGUF appears truncated");byte[] magic=new byte[4];f.readFully(magic);
            if(magic[0]!='G'||magic[1]!='G'||magic[2]!='U'||magic[3]!='F')throw new IOException("Selected file is not GGUF");
        }catch(Exception e){temp.delete();throw e;}
        Files.move(temp.toPath(),qwen().toPath(),StandardCopyOption.REPLACE_EXISTING);
        progress.update("Qwen GGUF installed on phone");
    }
    public void importKokoro(Uri uri,Progress progress) throws Exception {
        base().mkdirs();File stage=new File(base(),"kokoro-stage");delete(stage);stage.mkdirs();long extracted=0;int count=0;
        try(InputStream in=context.getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("Cannot open Kokoro archive");
            try(TarArchiveInputStream tar=new TarArchiveInputStream(new BZip2CompressorInputStream(new BufferedInputStream(in)))){
                TarArchiveEntry entry;
                while((entry=tar.getNextTarEntry())!=null){
                    if(++count>3000)throw new IOException("Archive contains too many files");
                    String path=entry.getName().replace('\\','/');
                    int root=path.indexOf('/');if(root!=-1)path=path.substring(root+1);
                    if(path.isEmpty())continue;
                    if(path.startsWith("/")||path.contains("../")||path.equals("..")||entry.isSymbolicLink()||entry.isLink())throw new IOException("Unsafe archive path");
                    // Only extract model data required for English synthesis.
                    if(!(path.equals("model.onnx")||path.equals("voices.bin")||path.equals("tokens.txt")||path.equals("lexicon-us-en.txt")||path.startsWith("espeak-ng-data/")))continue;
                    File file=new File(stage,path);if(!file.getCanonicalPath().startsWith(stage.getCanonicalPath()+File.separator))throw new IOException("Unsafe archive location");
                    if(entry.isDirectory()){file.mkdirs();continue;}
                    if(!file.getParentFile().isDirectory()&&!file.getParentFile().mkdirs())throw new IOException("Cannot create model directory");
                    try(OutputStream out=new BufferedOutputStream(new FileOutputStream(file))){
                        byte[] buffer=new byte[64*1024];int n;
                        while((n=tar.read(buffer))!=-1){out.write(buffer,0,n);extracted+=n;if(extracted>1_500_000_000L)throw new IOException("Kokoro archive too large");}
                    }
                    if(count%20==0)progress.update("Kokoro extracted: "+count+" entries");
                }
            }
            if(!new File(stage,"model.onnx").isFile() || !new File(stage,"voices.bin").isFile() || !new File(stage,"tokens.txt").isFile() || !new File(stage,"lexicon-us-en.txt").isFile() || !new File(stage,"espeak-ng-data").isDirectory())throw new IOException("Not the expected kokoro-multi-lang-v1_0 model pack");
            File destination=kokoro(); delete(destination);
            Files.move(stage.toPath(),destination.toPath(),StandardCopyOption.REPLACE_EXISTING);
            progress.update("Kokoro af_kore voice pack installed");
        }catch(Exception e){delete(stage);throw e;}
    }
    private static void delete(File f){if(f.isDirectory()){File[] children=f.listFiles();if(children!=null)for(File c:children)delete(c);}f.delete();}
}
