package org.kingdom.pocketscribe;

/** Qwen3.5 4B GGUF inference exclusively inside the Android process, without a localhost service. */
public final class QwenRuntime {
    private static boolean ready=false;
    public static synchronized boolean isAvailable(){
        if(!ready)try{System.loadLibrary("pocket_llm");ready=true;}catch(UnsatisfiedLinkError e){return false;}
        return true;
    }
    private static native String inferNative(String absoluteModelPath,String formattedPrompt,int maxOutputTokens);
    public static synchronized String infer(String modelPath,String system,String question,int limit){
        if(!isAvailable())throw new IllegalStateException("Native Qwen library not installed");
        // Qwen ChatML structure: model metadata remains authoritative for final tuning.
        String safeSystem=system.replace("<|","＜|");
        String safeQuestion=question.replace("<|","＜|");
        String prompt="<|im_start|>system\n"+safeSystem+"<|im_end|>\n"+
            "<|im_start|>user\n"+safeQuestion+"<|im_end|>\n"+
            "<|im_start|>assistant\n";
        return inferNative(modelPath,prompt,limit);
    }
}
