// Kingdom Pocket Scribe — Living Sigil visual firmware, milestone 2.
// M5StickS3: 135 x 240 screen, geometric rendering + serial-only DEV commands.
// WARNING: NO BLE, MICROPHONE CAPTURE, VOICE OUTPUT OR PERSISTENT PAIRING YET.
// State changes here are DEMONSTRATIONS, not claims that recording or research occurred.
#include <M5Unified.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

static M5Canvas sprite(&M5.Display);
static const int W=135, H=240, CX=67, CY=124;
static const float TAU=6.28318530718f;
static uint8_t currentMode=0, speechEnergy=0, micEnergy=0;
static uint32_t enteredAt=0, lastEnergyPacket=0, lastFrame=0;
static char input[48];
static uint8_t inputLength=0;
static bool spriteReady=false;
static const char* modes[]={"PRESENT","LISTENING","TRANSCRIBING","REFLECTING","RESEARCHING",
                            "COMPOSING","SPEAKING","YOUR JUDGMENT","SAVED","CONNECTION ISSUE"};
static const char* actions[]={"READY","MIC NOT CONNECTED","WORDS","THINKING","SOURCES",
                              "DRAFTING","SPEAKING","REVIEW NEEDED","COMPLETE","CHECK DEVICE"};
static const uint16_t colors[]={0xDD8B,0x76DD,0xE6B4,0xB51C,0x7E95,0xC71B,0xFE2E,0xED4E,0x8ED5,0xF46E};
static uint32_t savedUntil=0;

static int ix(float v){return static_cast<int>(lroundf(v));}
static void putLine(float x1,float y1,float x2,float y2,uint16_t c){
  sprite.drawLine(ix(x1),ix(y1),ix(x2),ix(y2),c);
}
static void polygonCircle(float x,float y,float rx,float ry,uint16_t c,int segments=52,float phase=0){
  float lastX=x+rx*cosf(phase),lastY=y+ry*sinf(phase);
  for(int j=1;j<=segments;j++){
    float a=phase+TAU*j/segments;
    float xx=x+rx*cosf(a), yy=y+ry*sinf(a);
    putLine(lastX,lastY,xx,yy,c);lastX=xx;lastY=yy;
  }
}
static void polygonArc(float x,float y,float r,float a,float extent,uint16_t c,int segments=18){
  float x0=x+r*cosf(a), y0=y+r*sinf(a);
  for(int j=1;j<=segments;j++){
    float an=a+extent*j/segments, nx=x+r*cosf(an), ny=y+r*sinf(an);
    putLine(x0,y0,nx,ny,c);x0=nx;y0=ny;
  }
}
static void dot(float x,float y,int r,uint16_t color){sprite.fillCircle(ix(x),ix(y),r,color);}
static void ring(float r,uint16_t c){polygonCircle(CX,CY,r,r,c);}
static void vesica(uint16_t c,float expand=1.0f){
  polygonCircle(CX-15,CY,32*expand,44*expand,c);
  polygonCircle(CX+15,CY,32*expand,44*expand,c);
}
static void drawNodes(const float (*points)[2],int count,uint16_t color,int lit){
  for(int i=0;i<count;i++){
    float x=CX+points[i][0], y=CY+points[i][1];
    sprite.drawCircle(ix(x),ix(y),i==lit?5:3,color);
    dot(x,y,i==lit?3:1,i==lit?0xFFDB:color);
  }
}
static void render(uint32_t elapsed){
  sprite.fillSprite(0x0000);
  uint16_t c=colors[currentMode];
  // Native-resolution fixed skeleton; dark background avoids unnecessary TFT backlight glare.
  sprite.drawRoundRect(3,3,W-6,H-6,7,0x422A);
  sprite.setTextDatum(textdatum_t::middle_center);
  sprite.setTextSize(1);
  sprite.setTextColor(0xCEB5);
  sprite.drawString("THE KINGDOM",CX,16);
  putLine(19,26,116,26,0x6349);
  sprite.drawString("SUNDAY SERMON",CX,40);
  sprite.setTextColor(c);
  sprite.drawString(modes[currentMode],CX,55);
  float seconds=elapsed/1000.0f;
  ring(52,0x3185);
  ring(47,0x1923);
  switch(currentMode){
    case 0: { // Idling/breathing: 8.4-second loop.
      float b=1.0f+0.043f*sinf(TAU*seconds/8.4f);
      vesica(c,b);ring(16,c);break;
    }
    case 1: { // Listening demo: intensity is injected, not captured from a live mic.
      vesica(c);
      float level=micEnergy/255.0f;
      for(int side=-1;side<=1;side+=2){
        for(int i=0;i<3;i++){
          float p=fmodf(seconds*0.8f+i/3.0f,1.0f);
          polygonArc(CX+side*(49-32*p),CY,17+level*15,side<0?3.5f:-0.6f,1.6f,c);
        }
      }break;
    }
    case 2: { // Transcribing marks traverse the center spine.
      polygonCircle(CX,CY,33,43,c);putLine(CX,CY-46,CX,CY+46,c);
      for(int i=0;i<11;i++){
        float y=CY-38+i*7;
        float k=fmodf(seconds*6,11);
        putLine(CX-((i%3)?6:10),y,CX+((i%3)?6:10),y,i==(int)k?0xFFDB:c);
      }break;
    }
    case 3: { // 3 circles + 7 points; evenly sequenced contemplation.
      for(int i=0;i<3;i++){
        float a=TAU*i/3-1.5707963f;
        polygonCircle(CX+22*cosf(a),CY+22*sinf(a),30,30,c);
      }
      float pts[7][2];
      for(int i=0;i<7;i++){float a=TAU*i/7-1.5707963f;pts[i][0]=41*cosf(a);pts[i][1]=41*sinf(a);}
      drawNodes(pts,7,c,(int)(fmodf(seconds,3.4f)*7/3.4f));break;
    }
    case 4: { // Ten-node research graph, NOT an actual Kabbalah diagram.
      const float pts[][2]={{0,-39},{-26,-24},{26,-24},{0,-12},{-30,3},{30,3},{0,14},{-22,29},{22,29},{0,42}};
      const uint8_t edges[][2]={{0,1},{0,2},{1,3},{2,3},{1,4},{2,5},{3,6},{4,6},{5,6},{4,7},{5,8},{6,7},{6,8},{7,9},{8,9}};
      for(const auto& edge:edges)putLine(CX+pts[edge[0]][0],CY+pts[edge[0]][1],CX+pts[edge[1]][0],CY+pts[edge[1]][1],c);
      drawNodes(pts,10,c,(int)fmodf(seconds*2,10));break;
    }
    case 5: { // Six-petal rosette converges to orderly center.
      float shift=4.0f*expf(-seconds*1.4f);
      for(int i=0;i<6;i++){
        float a=TAU*i/6;
        float x=CX+(22+shift)*cosf(a),y=CY+(22+shift)*sinf(a);
        polygonCircle(x,y,19,19,c);
      }
      putLine(CX-42,CY,CX+42,CY,c);putLine(CX,CY-45,CX,CY+45,c);break;
    }
    case 6: { // Voice response: bounded envelope value provided by *external* input.
      float v=speechEnergy/255.0f;
      ring(12+7*v,c);ring(23+9*v,c);ring(34+6*v,c);ring(45+5*v,c);
      vesica(c,1.0f+v*.03f);
      dot(CX,CY,2+ix(v*4),0xFFDB);break;
    }
    case 7: { // Judgment: incomplete geometry, unresolved node.
      for(int i=0;i<3;i++)polygonArc(CX,CY,43,i*TAU/3+.1f,1.45f,c);
      for(int i=0;i<7;i++){
        float a=TAU*i/7-1.57f;
        dot(CX+39*cosf(a),CY+39*sinf(a),i==2?5:2,c);
      }break;
    }
    case 8: { // Saved overlay; only host may request after actual persistence.
      vesica(c);ring(30,c);
      putLine(CX-18,CY,CX-4,CY+12,c);putLine(CX-4,CY+12,CX+23,CY-18,c);break;
    }
    case 9: { // Connection issue is explicitly an error state.
      for(int i=0;i<4;i++)polygonArc(CX,CY,43,i*TAU/4+.18f,1.05f,c);
      putLine(CX-28,CY-28,CX+28,CY+28,c);break;
    }
  }
  dot(CX,CY,3,0xFFFB); // one center remains present in every state
  putLine(19,194,116,194,c);
  sprite.setTextColor(c);sprite.drawString(actions[currentMode],CX,210);
  sprite.setTextColor(0x8C51);
  sprite.drawString("USB DEMO / NO BLE",CX,225);
  sprite.pushSprite(0,0);
}
static void setMode(unsigned int v){
  if(v>9)return;
  currentMode=(uint8_t)v;enteredAt=millis();
  if(v==8)savedUntil=enteredAt+1000;
}
static bool parseUnsigned(const char *start,int limit,uint8_t &value){
  if(!*start)return false;
  char *end=nullptr;
  unsigned long result=strtoul(start,&end,10);
  if(end==start||*end!='\0'||result>(unsigned long)limit)return false;
  value=(uint8_t)result;return true;
}
static void processCommand(const char* command){
  uint8_t value=0;
  if(strcmp(command,"?")==0){Serial.printf("SIGIL/1 mode=%u energy=%u mic=%u ble=0\n",currentMode,speechEnergy,micEnergy);return;}
  if(strlen(command)<3||command[1]!=' '){Serial.println("ERR command");return;}
  if(!parseUnsigned(command+2,255,value)){Serial.println("ERR value");return;}
  switch(command[0]){
    case 'S':if(value<=9){setMode(value);Serial.println("OK state");}else Serial.println("ERR state");break;
    case 'E':speechEnergy=value;lastEnergyPacket=millis();Serial.println("OK energy");break;
    case 'M':micEnergy=value;Serial.println("OK mic");break;
    default:Serial.println("ERR command");break;
  }
}
void setup(){
  auto config=M5.config();M5.begin(config);
  Serial.begin(115200);
  M5.Display.setRotation(0);
  if(M5.Display.width()>M5.Display.height())M5.Display.setRotation(1);
  sprite.setColorDepth(16);
  spriteReady=sprite.createSprite(W,H)!=nullptr;
  if(!spriteReady){M5.Display.fillScreen(0);M5.Display.println("Sigil sprite allocation failed");}
  enteredAt=lastEnergyPacket=millis();
  Serial.println("SIGIL/1 READY SERIAL-DEMO NO-BLE");
}
void loop(){
  M5.update();
  // On-device buttons are preview navigation only; they do not activate the microphone.
  if(M5.BtnA.wasPressed())setMode((currentMode+1)%10);
  if(M5.BtnB.wasPressed())setMode(0);
  int count=0;
  while(Serial.available() && count++<96){
    char ch=(char)Serial.read();
    if(ch=='\n'||ch=='\r'){
      if(inputLength){input[inputLength]='\0';processCommand(input);inputLength=0;}
    }else if(inputLength<sizeof(input)-1){input[inputLength++]=ch;}
    else{inputLength=0;Serial.println("ERR size");}
  }
  uint32_t now=millis();
  if(currentMode==8 && (int32_t)(now-savedUntil)>=0)setMode(0);
  // Avoid a frozen glow if envelope input disappears.
  if(spriteReady && (uint32_t)(now-lastFrame)>=50){
    lastFrame=now;
    if((uint32_t)(now-lastEnergyPacket)>200 && speechEnergy>0)speechEnergy=(uint8_t)(speechEnergy*0.79f);
    render(now-enteredAt);
  }
  delay(2);
}
