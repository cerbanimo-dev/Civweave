# M3 update — October 2026

**The Android app is now phone-first:** `MainActivity` ships bundled WebView assets and a native SQLite backend (`NativeStore`) through a narrow async native bridge. It no longer needs the Termux Python server or StickS3 to create, edit, search, export, import, and rehearse sermon projects. Android on-device SpeechRecognizer and Android system TTS provide optional phone voice input/output; the Kokoro model/runtime is not integrated into the built app. Optional AI uses an explicitly configured HTTPS/on-phone loopback endpoint; Qwen weights are not included.

See `docs/mobile-alpha-testing.md` for implemented scope, test evidence, and pending on-device acceptance. The following document describes the **longer-term target architecture**, not the current alpha's completed implementation.

---

# Full-stack architecture — target implementation

## Delivery layers

```
StickS3 (ESP32-S3) — bonded BLE GATT (buttons, transport health, mic frames, PCM reply)
            ⇅
Android app — Jetpack Compose/Room/WorkManager/Android Keystore
  ├── Device service: BLE, audio route, push-to-talk, reconnect
  ├── Voice service: sherpa-onnx ASR + Kokoro 82M, af_kore sid=5 speed=1.5
  ├── Orchestrator: bounded tools, validation, provenance, manual approval
  ├── Model service: embedded llama.cpp / Qwen3.5 4B Q4_K_M
  ├── Index: SQLite FTS5 / local document chunks / source metadata
  ├── Projects: notes, study, manuscripts, rehearsal and task planning
  └── Sync outbox: explicit-per-object opt-in + authenticated encrypted transport
            ⇅ (only when enabled)
Kingdom cloud (auth, encrypted storage, public research connector, federation)
```

**Current starter:** a working local Python+SQLite API, browser workbench, Android loopback WebView shell, hardware UI smoke firmware and Kokoro integration reference. It is not yet a complete native production implementation. The research/citation pipeline, embedded TTS/ASR, BLE audio, and federation synchronization are planned components; labels reflect this accurately.

## Device memory strategy, Galaxy S25+ / 12 GB

- Allocate **one** main LLM context at a time (start at 4,096 tokens; don't assume 16K/32K fits smoothly).
- Qwen3.5 4B Q4_K_M approx 2.7GB weights, plus runtime and KV cache; test actual Android resident set size rather than summing weights.
- Use a small streaming English ASR model or whisper-class medium/small quant, **not** large ASR alongside a full LLM.
- Kokoro 82M approx 310 MB ONNX model plus ~26 MB voices and language assets. Load TTS on demand. CPU four threads initially, measure thermals and battery.
- Cap parallel model execution at 1 for initial builds. Transcribe, unload or pause ASR, run reasoning, synthesize in chunks. Keep interactions responsive using streaming text when available.
- Default voice settings: af_kore, SID 5 for *Kokoro v1.0 53-speaker pack only*, speed 1.5, no pitch shift. Do **not** use v1.1 speaker map interchangeably.
- Energy strategy: push-to-talk, no always-listening hot microphone, screen-off service only while recording/playback, cancellation must stop inference and release audio.

## Four pastoral workspaces

1. Sermon Inbox: captured audio/transcriptions, questions, pastoral ideas, journal and tagged notes.
2. Scripture Study: passage context, parallel translations if licensed, Greek/Hebrew lexicon, theological commentary comparisons, linked quotations with actual source provenance and verified URLs.
3. Sermon Workshop: outlines, textual revisions, delivery-length planning, AI critique, alternative perspectives, editable draft history.
4. Pulpit Studio: delivery scripts, rehearsals and timers, voice practice, speaker notes, task completion, date and service preparation.

## Living Sigil avatar

A non-human geometric companion, distinct from the Kokoro voice model. Ten modes: idle, listening, transcribing, thinking, researching, writing, speaking, judgment, saved, and error. Central light remains constant; user can disable motion. The browser workbench now reflects real request and persistence actions. StickS3 renderer currently accepts **local USB demonstration commands only**; native voice playback and protected BLE are not yet integrated. Browser audio file preview drives voice level from actual playing audio; Android Kokoro playback-clock callback exists as **uncompiled integration reference** in `android/integrations/`. Animations must not imply unsourced thoughts or false connection states. See `living-sigil-states.md`, `sticks3-serial-bringup.md`, and `kokoro-voice-resonance.md`.

## Civweave / Kingdom preservation

The historical v4 Kingdom mobile shell is preserved in `legacy/`. Maintain Passport, mutually witnessed receipts, Service circles, Jubilee review, federation, local consent and provenance. Share document/learning/quest structures through **versioned adapters**; no automatic bi-directional sync, no data migration until contract and user approval are implemented.

## Privacy and safeguarding

- Sermons/drafts PRIVATE by default; pastoral counseling notes are more sensitive. No third-party research query may include a pastoral person's identity or private text unless intentionally approved.
- Local SQLite in this development package is **not encrypted**. Do not ingest private pastoral counseling or confidential church data until Android Keystore-backed encryption and access controls are added.
- No public-facing server; local Python binds 127.0.0.1 only. Never open the Termux service to Wi-Fi. Cloud deployment requires auth, authorization, encryption at rest/in transit, per-object access policy and tamper-evident audit.
- Prompt injection from retrieved documents is treated as untrusted input; answers require verified external sources before publication.
- Public domain Bible passages are not the same as all modern Bible translation rights; decide licensing for each translation before bundling.

## Pocket accessory transport v1 proposal

- BLE bonded + encrypted pairing. GATT characteristics: transport-state, control-events, inbound-audio and outbound-audio. Device frames include version, monotonic sequence number, payload type, and message boundary.
- Button A: push-to-talk press/release. Button B: review last captured item / cancel speech. Screen: listening, connected, private, battery, and short preview.
- Audio: evaluate Opus at 16kHz mono low bitrate over BLE, with bounded queues and jitter handling; ESP32-S3 memory/performance/latency must be validated on actual hardware. Fallback to phone microphone if pairing disconnects.
- Device never receives cloud credentials, source notes or raw PII unless explicitly needed; no always-open unauthenticated service.

## Acceptance gates before gifting

1. 30 min continuous read-aloud with `af_kore` at 1.5×, no freezes or clipping; monitor CPU thermals.
2. 50 voice captures with no loss, duplicate, or incorrect sermon assignment; local failover on disconnect.
3. Offline cold start, full airplane-mode sermon creation, transcription and TTS.
4. Grounded cited research: no fabricated source links or verse quotations in accepted test sets.
5. Native app can survive process death, resume audio and restore projects without corruption.
6. Secure pairing, explicit consent for sync, encrypted backup/restore, and isolated church accounts.
7. Full regression from Kingdom v4 features with zero changes to base feature IDs / consent rules.
