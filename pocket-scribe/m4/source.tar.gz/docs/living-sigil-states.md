# The Living Sigil — screen-by-screen motion and integration specification

Version `kingdom.living-sigil.states.v1` — device-first design package (24 October 2026).

## Device coordinate contract

StickS3 native LCD: **135 wide × 240 high**, portrait orientation (M5Unified rotation 0; verify physical orientation during bring-up). The interactive preview renders in this native coordinate system at an enlarged browser resolution. One spiritual-geometric **central light** remains fixed at `(67.5, 125)` in all screens, including errors, to communicate identity continuity.

- Margins: 5 px frame; project heading centered at Y=39; state label Y=55.
- Primary glyph: radius 52 px, centered at `(67.5,125)`.
- Status divider: Y=194; concise action label: Y=210; connection indicator: Y=225.
- Favor 1–2 px high-contrast lines and avoid placing complex text inside the geometry.
- Draw the majority of the frame in-device; do **not** transfer rendered frames over BLE.

## Core eight states

| Key | State label / color | Composition | Motion | Real triggering event |
| --- | --- | --- | --- | --- |
| `idle` | PRESENT · old-gold `#DFB36E` | Two overlapping vesica circles; small concentric center | 8.4 s gentle breath, 0–4.5% scale | App is connected, no active task |
| `listening` | LISTENING · cyan `#71D8EB` | Vesica with inward-facing arcs | Wavefronts move toward center, modulated by microphone RMS | Actual push-to-talk capture begins |
| `transcribing` | TRANSCRIBING · ivory `#E6D2A3` | Vertical illuminated spine with transverse marks | Brief marks brighten in sequential descent | Audio is sent to working speech recognition |
| `thinking` | REFLECTING · violet `#B7A0ED` | Three intersecting circles with seven orbital nodes | One active node per segment of 3.4 s loop; subtle three-ring expansion | Local or remote model is generating / working |
| `researching` | RESEARCHING · emerald `#7AD6AB` | Ten-node branching research network, not a historical sefirot reproduction | Edge/node progression while searching; ideally highlight confirmed source additions | Actual research/source tool is running |
| `writing` | COMPOSING · pale green `#C9E7BD` | Six-part converging rosette, organizing cross axes | Petals settle inward; then hold the assembled form | Draft/outline generation or editorial transform |
| `speaking` | SPEAKING · amber-gold `#F8C475` | Central light with four concentric pulse rings | Radius, luminance and ring bloom map from **playback** energy; fall back to rest at silence | Kokoro AudioTrack playback begins (not synthesis completion) |
| `judgment` | NEEDS JUDGMENT · warm amber `#EDA875` | Incomplete outer ring and one highlighted unresolved node | Controlled 2–3 s pulse, no urgent flashing | Approval / theological review / citation verification explicitly required |

Two further system overlays:

- `saved`: **SAVED** · soft green `#86D8AA`, stable checkmark nested in vesica, briefly hold (1.0 s in the final runtime) then return to prior connected state. Only show after persistent write completes.
- `error`: **CONNECTION LOST** · red-orange `#F08D74`, interrupted circular line segments; remain steady until connectivity actually returns. Never label this `CONNECTED`.

## Semantic and theological boundaries

Base forms: vesica piscis, mandorla and triadic rosette inspired by Christian visual traditions. The ten-node **research network** is intentionally an abstract connection diagram; it does not purport to reproduce Jewish Kabbalah's Tree of Sefirot or reduce its religious meaning to UI progress. Historical Jewish Kabbalah and Christian Cabala belong in research/reference modes with correct sourcing and labeling. Do not present research nodes as actual AI thoughts, divination, prayer, theological authority or divine revelation.

## Animation timing recommendations

- Idle: 8.4-second cycle, ±4.5% scale from midpoint. In production aim for 15–20 fps on device, subject to measurements; canvas preview uses requestAnimationFrame.
- Thinking: 3.4-second cycle divided across seven nodes, modest overall expansion, never intensify motion simply because response generation is slow.
- Listening: approximately 20–30 ms audio RMS window; envelope attack 40–70 ms, release 140–220 ms.
- Speaking: compute a normalized short-window audio envelope from **actual PCM routed to playback**, not synthesized text length or precomputed estimated words. Preferred 20–40 ms windows, 20–30 update packets per second if connected transport permits.
- Visual values are normalized to `[0,1]`, attack should be brisk and decay soft, with minimum 0.06 glow in speaking silence.
- Respect reduced motion by freezing rings and preserving static color/state distinctions. Never use rapid flashing.

## Kokoro + BLE synchrony design

1. Kokoro `af_kore`, speed 1.5×, generates PCM on phone (native AAR/runtime integration remains uncompiled in the starter).
2. Feed generated PCM into a `MODE_STREAM` playback queue. From the same frames compute RMS by summing squares divided by sample count and taking square root, then gently normalize/limit and optionally detect onset.
3. Keep each envelope window tied to the sample interval's **playback timestamp**, using the AudioTrack playback head or a consistent audio clock. An envelope emitted as soon as the TTS response is generated may lead the sound substantially.
4. Send a compact, versioned packet with `(sequence, playback_timestamp_ms, intensity_byte, state_id, flags)` via bonded authenticated BLE, paced around 25 Hz and with enough lead time to smooth jitter. Anchor the device-side clock to real playback start. Do not send raw sermon text/identities on this animation channel.
5. StickS3 interpolates intensity from recent events; if packets stop, decay gracefully rather than freezing a bright ring. On `playbackStopped`, fade to idle or requested next state.
6. If audio routes to the StickS3's **own speaker**, synchronization should use the device's decoded-playback clock rather than a phone-only estimate. This requires the separate audio transport work still marked as planned.

An example conceptual packet (not the shipping wire format):

```json
{
  "schema": "kingdom.sigil.envelope.v1",
  "seq": 401,
  "state": "speaking",
  "playback_ms": 1840,
  "energy": 186,
  "onset": true
}
```

`energy` is an unsigned byte 0–255. The rendering interface consumes energy/255; never interpret it as user emotion or spiritual quality. Transport implementation must validate packet size, freshness, and pairing.

## State transitions and claims

```
idle -> listening -> transcribing -> thinking
thinking -> researching -> thinking
thinking -> writing -> speaking -> idle
thinking -> judgment -> thinking
any -> saved (after actual storage commit) -> previous state
any -> error (actual transport failure), recovery -> idle
```

- The visual state is a projection of **real runtime events**. If a request remains queued, show queued status rather than a fictitious active research animation.
- If a task is cancelled, end its active state, clear stale audio, and show a restrained confirmation.
- Do not present `saved` before the storage layer acknowledges a completed transaction.
- No personal pastoral information is rendered on the device by default. Device displays generic sermon title unless explicitly allowed.

## Implementation handoff

The production implementation should use one state manager broadcasting normalized animation commands to two renderers: `StickS3Renderer` (geometry primitives + TFT framebuffer/sprite) and `AndroidRenderer` (Canvas/Compose GL or equivalent). The prototype currently uses the matching 135×240 device math in JS canvas at `visuals/living-sigil/sigil.js`, and its phone-expanded counterpart in the same module. Drawing math can be ported directly into C++ or native Kotlin once BLE events and audio playback are functional.

The ZIP does **not** claim that StickS3 firmware, BLE audio, Kokoro model weights, or native playback audio synchronization are finished. This release provides design, image assets, and an executable browser demonstrator.
