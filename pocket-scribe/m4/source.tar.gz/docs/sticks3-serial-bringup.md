# StickS3 Living Sigil — serial-only bring-up

This milestone **draws native resolution geometric animations on the M5StickS3**. It is **not** a paired companion. No microphone, speaker, research, BLE transport, or audio playback is implemented on the firmware yet. Do not load real pastoral material onto this test interface.

## Build

1. Install PlatformIO on your computer and connect the StickS3 by USB.
2. From `firmware/`, run `pio run` and then `pio run --target upload` for `m5stack-sticks3`.
3. The display animates the resting symbol. Front button cycles ten demonstration states; side button returns to rest.
4. Read logs at 115200 baud using `pio device monitor -b 115200`. The greeting should be `SIGIL/1 READY SERIAL-DEMO NO-BLE`.

This project has not been flashed or compiled on target hardware in the current environment. If M5Unified board-library APIs/rotation differ with your installed version, correct and test with the physical device before deployment.

## Serial protocol — development only

One ASCII command per line at 115200 baud, with maximum 47 chars per command. Replies are `OK ...` / `ERR ...`. No data is persisted.

| Message | Meaning |
|---|---|
| `?` | Show renderer status, including `ble=0` |
| `S 0` through `S 9` | Switch to idle, listening, transcribing, thinking, researching, writing, speaking, judgment, saved or error |
| `E 0` through `E 255` | Provide normalized speaking energy, fades toward zero if packets stop for 200 ms |
| `M 0` through `M 255` | Provide normalized listening energy |

`python tools/serial_demo.py --port COM5 --state thinking` sends a test state; use a COM port appropriate to your machine. This protocol is **not authenticated** and must only be used across a locally controlled USB cable in development; it must **never** be exposed as a network, BLE, or production control channel.

## Production upgrade path

Implement bonded/authenticated BLE GATT for state and visual envelope, and actual playback sync using timestamps linked to Kokoro's audio output clock. Validate packet freshness and device identity. Keep private sermon text out of visual packets. For device-speaker voice output, drive animation from its *own* playback position rather than from phone synthesis completion.
