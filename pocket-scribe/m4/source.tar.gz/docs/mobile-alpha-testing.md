# Pocket Scribe M3 — Android standalone alpha release notes

## Delivery purpose
The Galaxy S25+ must serve as a **complete manual sermon workshop** even if no StickS3 is paired. No Bluetooth code is in the app's critical path. The Pocket Scribe AI and special Kokoro voice are enhancements whose model dependencies are **not included**.

## Architecture actually included

- Native Android `MainActivity.java` loads the bundled `file:///android_asset/index.html` workbench using a locked-down WebView.
- Native `NativeStore.java` persists sermon projects, sermon inbox notes, sources, manuscripts, pulpit tasks, and imported archives in private Android SQLite. It provides the same route shapes as the dev Python API through a narrowly scoped JS bridge.
- Android on-device `SpeechRecognizer` dictation is available if the phone has an **on-device speech service/language pack**. It never falls back silently to an online recognizer. Text entry always works.
- Android `TextToSpeech` is the alpha read-aloud engine, with rate defaulting to 1.5×. This is **not** Kokoro and its speech rhythm is **not** yet driven from actual PCM.
- An optional native OpenAI-compatible HTTP(S) request implementation accepts **HTTPS** endpoints or on-phone loopback HTTP only. An AI model is not bundled or installed. HTTPS submission requires explicit confirmation every time; project note context is shared only if explicitly checked.
- Android Storage Access Framework handles JSON export/import; no storage-wide permission required.
- Standalone web version remains useful for desktop dev via `python server/app.py` but is **not** required by the Android app.

## Automated checks performed in the source environment

- `python -m unittest discover -s tests -v` — 17 PASS (Python local API operations, archive import/rollback, UI asset integrity, native implementation structure, prior visual modules).
- `node --check web/app.js` — PASS (JavaScript syntax).
- `python -m py_compile server/app.py` — PASS.
- **Android compilation/APK:** NOT RUN. The execution environment has no Android SDK, Gradle, or connected device. Do not distribute this source bundle as a verified APK.
- **Live browser UI interaction:** ATTEMPTED, NOT RUN TO COMPLETION. The managed Chromium environment blocks navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`) even to local files/loopback.

## Build the debug APK

**Option A — Android Studio:** Open the `android/` directory as the project. Install Android SDK platform 36 and Build Tools 35.0.0, configure Gradle 8.13 with JDK 17, sync the project and choose **Build > Build APK(s)**. The resulting file is `android/app/build/outputs/apk/debug/app-debug.apk`. If your installation requires a Gradle wrapper, run `gradle wrapper --gradle-version 8.13` once from `android/` before syncing.

**Option B — GitHub Actions:** Push this repository structure into a GitHub repository, open **Actions > Build Pocket Scribe Android Alpha > Run workflow**, and download the `pocket-scribe-m3-debug-apk` artifact if the build succeeds. The workflow under `.github/workflows/android-debug-apk.yml` is supplied but has **not** been executed here.

For a connected Android test phone with USB debugging enabled:

```sh
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

Do not uninstall a prior build containing user data. The new native SQLite store is separate from the old Termux Python server and **does not automatically migrate** the old DB. Export old sermons from the previous workbench and import each into the new phone app.

## Hands-on Galaxy S25+ acceptance checklist (pending)

- [ ] Install debug APK and launch in airplane mode, with no Termux running and StickS3 off.
- [ ] Create a sermon, set passage/date, reopen app and verify persistence.
- [ ] Create, edit, search, and delete notes and sources; verify no unexpected data loss.
- [ ] Make a sermon outline from the template, revise and save it, then complete a rehearsal task.
- [ ] Grant microphone permission; dictate into a note and a question, verify transcript; repeat with no speech pack / denied permission to confirm clear fallback.
- [ ] Read a manuscript at 1.5× and stop playback; check speech starts/stops cleanly across app backgrounds.
- [ ] Export sermon JSON to Downloads with Android file picker; import it; verify a distinct duplicate with the expected note count.
- [ ] Disconnect network; confirm all manual workflows still work.
- [ ] Confirm AI says *not configured* by default. Configure a permitted endpoint and test manually. For HTTPS, verify approval is required before every request; private project notes are excluded unless checked.
- [ ] Tap reference links to confirm external browser handoff; verify the in-app WebView never loads remote scripts.
- [ ] Navigate all ten avatar states in the preview, including reduced-motion settings.
- [ ] Rotate display, multitask, relaunch, deny permission, and interrupt exports; inspect for crashes or duplicated saves.
- [ ] Observe memory, CPU, heat, and battery during lengthy manual note-taking / TTS; verify Android 15/16 edge-to-edge insets.
- [ ] Check screen reader labels and text zoom.

## Scope boundaries

| Feature | M3 status |
|---|---|
| Four manual sermon workspaces | Implemented in native web assets + local database, pending device confirmation |
| Phone mic speech-to-text | Integrated via Android on-device recognizer; depends on installed speech pack, untested on phone |
| Phone speech output | Integrated via Android system TTS fallback; Kokoro not bundled |
| Local source citations | Manual saved-source records; no automatic citation verification |
| Sermon backup / restore | Android JSON file picker and import transaction |
| AI drafting | Optional user-configured OpenAI-compatible endpoint; no local LLM packaged |
| Offline biblical translation library | Not bundled yet |
| Cloud research/search & Kingdom sync | Not implemented; user can open external browser links |
| Live Kokoro waveform animation | Not yet integrated into Android TTS |
| StickS3 pairing/voice | Not required; not part of this mobile milestone |
| At-rest encryption for sensitive pastoral records | Not implemented; do not store confidential counseling information |
