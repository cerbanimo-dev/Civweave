# Milestone 4: Galaxy S25+ standalone engines

**Build status: source prepared; GitHub Actions APK build and phone smoke tests are not yet verified.**

## Offline Qwen (local CPU-first)

- llama.cpp v0.5.0 is cloned during build and packaged through a JNI native library, for arm64-v8a.
- No cloud endpoint is required. Optional HTTPS endpoints remain available only when explicitly configured.
- Download `Qwen3.5-4B-Q4_K_M.gguf` (about 2.8 GB) from a trusted, appropriately licensed publisher such as [SoAIHQ/Qwen3.5-4B-GGUF](https://huggingface.co/SoAIHQ/Qwen3.5-4B-GGUF). On Android choose **Import Qwen3.5 4B GGUF** and select the file with the Android document picker.
- Import copies into private app storage. Ensure at least 5 GB free for the original download plus app-private copy.
- Limits: CPU inference, one request at a time, context 4096, max output 768 tokens, 4 threads. Speeds, memory usage and thermal behavior require S25+ testing. No online research and no verified citations are implied.
- Original source notes are only included when the user toggles the per-request context box.

## Offline Kokoro `af_kore`

- sherpa-onnx v1.13.8 is downloaded as an AAR during build; the AAR SHA-256 is verified.
- Get the official `kokoro-multi-lang-v1_0.tar.bz2` archive: [upstream release](https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-multi-lang-v1_0.tar.bz2).
- Use **Import Kokoro voice pack** on Android to extract this archive into private app storage. The importer keeps only the English model, voices, tokens, phonemizer data and English lexicon.
- `sid=5` in the v1.0 voice table selects `af_kore`; synthesis speed is **1.5x**, without speeding the playback sample rate or altering pitch.
- An `AudioTrack`-based playback head drives real-time waveform energy values to the Living Sigil.
- If the pack is not installed, Android TTS remains available. The Kokoro native synthesis path is still pending actual device confirmation.

## GitHub Actions

Run `.github/workflows/android-debug-apk.yml` on a repository containing this project at its root. The workflow installs SDK, NDK and CMake; fetches/validates native dependencies; tests; builds the debug APK; and uploads it as a GitHub artifact. The workflow needs permissions to run GitHub Actions and network access for dependencies. The GitHub connector's exposed methods may not support `workflow_dispatch`; pushing the source on a branch with the workflow triggers the `push` event automatically.

## Device acceptance

1. Install APK with source verification from an authenticated GitHub Actions artifact.
2. Make a sermon, notes, drafts, source citations, tasks; airplane mode; force stop/reopen; verify persistence.
3. Import Qwen GGUF; in airplane mode generate a sermon outline and verify that the output is marked unverified.
4. Import Kokoro model archive; in airplane mode read a draft, verify voice identity and speed, and check the sigil pulses during actual playback.
5. Try Stop speaking; switch audio route and interrupt playback; verify no deadlock.
6. Turn device over to phone-only mode; no M5StickS3 pairing, Termux, external model process, or cloud token should be required for normal operation.
7. Verify the model imports reject malformed/truncated/path-traversing files and never leak user data remotely.
