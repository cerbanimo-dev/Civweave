# Milestone 2 — Living Sigil integration and playback resonance

October 2026 continuation of the S25+ Pocket Scribe starter.

## Delivered

1. Replaced the Lampkeeper visual placeholder with animated Living Sigil Canvas rendering in the sermon workbench (`web/index.html`, `web/app.js`, `web/styles.css`). States reflect real application events: server outage, local save acknowledgement, active local-model request, AI endpoint unavailable/review.
2. Served the standalone ten-state preview through `/sigil-demo/` in the existing localhost-only Python server.
3. Added a browser audio player that analyzes the amplitude of **actual locally playing audio**; no file upload or Kokoro claim.
4. Added pure JavaScript PCM RMS/quantized binary packet utilities and tests; wire format is only a proposal, not a secure transport.
5. Implemented a ten-state native-resolution StickS3 geometric renderer with local button previews and serial-only diagnostic commands; physical board compilation and flashing remain unverified.
6. Updated the **uncompiled** Android Kokoro reference to use AudioTrack MODE_STREAM and emit visual pulses corresponding to the playback head, not synthesis completion. Kept `af_kore` speaker ID 5, speed 1.5× for the pinned model pack.
7. Retained the original notes/drafts/sources/projects/export behavior and upgraded local DB sessions to close their connections.

## Validation

- Python `unittest`: 12 tests passing, including API/visual routes and unchanged sermon persistence.
- Node.js `node:test`: 3 tests passing for RMS/envelope/quantized packet.
- JavaScript parsing checks: passing.
- C++ host syntax check against a **minimal stub** for M5Unified: passing. This **does not** establish compatibility with actual M5Stack libraries, device flashing, memory or performance.
- Automated Chromium browser navigation was blocked by the test environment; **no browser UI interaction claim is made** for this build. Existing prior visual preview images remain included.

## Not implemented

- Native Android runtime/voice model packaging or working APK
- Real mobile speech recognition, recording or secure BLE pairing
- StickS3 audio output and synchronized audio playback
- Real phone-to-StickS3 visual packets, reconnection and clock sync
- Background Android companion service, TTS model assets, Cloudflare federation
- End-to-end live hardware performance / battery measurement

## Next hardware gates

1. Build and flash firmware on the actual M5StickS3; confirm display rotation, buttons, CPU and sprite memory.
2. Install sherpa-onnx Kokoro on the S25+ and verify 1.5× `af_kore` audible playback and callback timing.
3. Implement bonded BLE GATT transport, handshake, freshness and authenticated encrypted pulse packets.
4. Record phone-vs-Stick visual latency; synchronize pulse to the output clock, and test screen-off Android behavior.
5. Implement actual capture/ASR and map capture/status to existing workspaces and persisted notes.
