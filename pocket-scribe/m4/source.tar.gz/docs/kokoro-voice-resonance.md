# Kokoro voice resonance: playback-clock design

The reference integration `android/integrations/KokoroTtsService.kt` has been upgraded from one large `AudioTrack.MODE_STATIC` playback to `MODE_STREAM` with a playback-head-driven pulse callback. This is a **reference file only**, not a build-tested Android module: the native AAR and model weights are absent.

- Kokoro 82M `af_kore` (speaker ID 5 in the pinned v1.0 voice pack), 1.5× generation speed.
- Generate normalized RMS amplitude from 32 ms windows of synthesized PCM, following speaker playback position via `AudioTrack.playbackHeadPosition`, never sending the whole envelope immediately at synthesis completion.
- Phone UI should update on the main thread from `onPulse`, with lightweight attack/release smoothing. On speaking completion, fade to idle. When paused or interrupted, drop stale envelope entries.
- To render on a StickS3 over **future authenticated BLE**, transmit `SigilPulse` with timing referenced to the phone's playback head. Maintain a smooth jitter buffer and reject stale frames. Do not route this unencrypted. If sound plays on the StickS3 speaker instead, compute pulses from its playback clock.
- Browser visual preview can already animate from *actual locally selected audio*, using its AudioContext Analyser node. This isn't Kokoro synthesis.

## Proposed visual BLE packet: `kingdom.sigil.visual.v1`

Binary, little endian, 12 bytes. Prototype codec in `visuals/living-sigil/voice-envelope.js`. Not shipped over BLE yet.

| Bytes | Field | Range |
|---|---|---|
| 0 | Magic | `0xA5` |
| 1 | Packet version | `1` |
| 2 | State ID | 0–9 (idle → error) |
| 3 | Flags | bit 0 = syllabic/onset event, other bits must be 0 |
| 4–5 | Sequence | unsigned 16-bit, wraps |
| 6–9 | Playback elapsed milliseconds | unsigned 32-bit LE |
| 10 | Speech intensity | 0–255 |
| 11 | Microphone intensity | 0–255 |

No usernames, sermon text, scripture passages, recordings or private content goes into animation packets. Message freshness, session identifiers, replay defense, GATT pairing, and BLE security are still needed before this can become a shipping protocol. The timestamp alone is not sufficient to synchronize independent clocks or defend against replay.

## Test steps

1. On a desktop, run `python server/app.py` and visit `http://127.0.0.1:8765/sigil-demo/`.
2. Change to Speaking and play a local audio file in the `Drive the sigil from actual audio playback` selector; its waveform controls the concentric rings.
3. Pause the audio: glow should decay to zero and state return to idle. No audio is uploaded.
4. Run `node --test tests/js/*.cjs` to exercise PCM/RMS, quantization and binary codec.
5. After sherpa-onnx is integrated into native Android, verify measured AV lag using recording or hardware timing; target sub-100-ms perceived mismatch, not a guarantee.

## Key remaining engineering work

On-device Android TTS/ASR packaging, bidirectional bonded BLE transport, real microphone capture, reconnection, sync outbox, per-device A/V clock alignment, phone background service and hardware measurements. The current starter is not a working hands-free device.
