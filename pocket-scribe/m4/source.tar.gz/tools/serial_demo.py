#!/usr/bin/env python3
"""Optional developer serial transport: test the Living Sigil without fake BLE.
Requires pyserial, and a StickS3 flashed with firmware/src/main.cpp.
Example: python tools/serial_demo.py --port COM5 --state thinking
Does not record or play audio, access sermons, or change cloud services.
"""
import argparse
import time

MODES=('idle','listening','transcribing','thinking','researching','writing','speaking','judgment','saved','error')

def command_bytes(mode, energy=0):
    if mode not in MODES:raise ValueError('Unknown sigil mode')
    if isinstance(energy,bool) or not isinstance(energy,int) or not 0<=energy<=255:
        raise ValueError('Audio level must be 0..255')
    return f'S {MODES.index(mode)}\nE {energy}\n'.encode('ascii')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',required=True)
    parser.add_argument('--baud',type=int,default=115200)
    parser.add_argument('--state',choices=MODES,default='thinking')
    parser.add_argument('--energy',type=int,default=0)
    args=parser.parse_args()
    try:import serial
    except ImportError:parser.error('Install pyserial locally: python -m pip install pyserial')
    try:packet=command_bytes(args.state,args.energy)
    except ValueError as exc:parser.error(str(exc))
    with serial.Serial(args.port,args.baud,timeout=1) as port:
        time.sleep(1.3) # allow microcontroller reset after serial port opens
        port.write(packet);port.flush()
        for _ in range(3):
            response=port.readline().decode('utf8','replace').strip()
            if response:print(response)
if __name__=='__main__':main()
