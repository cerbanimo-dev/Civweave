# The Living Sigil — interactive animation design

Open `index.html` in a browser. All assets are local and the prototype has no network or runtime dependencies. Click any state button to switch the same symbolic avatar between device-size and expanded phone previews.

Core states: idle, listening, transcribing, thinking, researching, writing, speaking, judgment. Supplementary status states: saved and error.

- `contact-sheet.png`: static screen-by-screen design overview.
- `assets/*-135x240.png`: ten screen mockups at true display resolution.
- `assets/*-3x.png`: enlarged screen mockups for viewing and reviews.
- `assets/preview-page.png`: full designer-tool screenshot.
- `sigil.js`: geometric raster renderer, motion system and public integration methods.
- `styles.css`: standalone prototype interface.
- `../../docs/living-sigil-states.md`: screen layout, timing, colors, semantics and BLE/voice envelope design.

## Public animation API

```js
LivingSigil.setMode('thinking');
LivingSigil.setMode('speaking');
LivingSigil.setVoiceLevel(0.6);
LivingSigil.pushPcmSamples(new Float32Array([0.05, -0.1, 0.14]));
LivingSigil.setMicLevel(0.4);
```

The demo button generates a synthetic waveform for preview only. To sync **Kokoro**, feed PCM energy at the playback clock, not synthesis time. Native Android and BLE integration remains for the next build stage.

The images are visual design artifacts, not firmware-ready compiled sprites. For embedded use, port the line/circle paths into the device's rendering API to preserve smooth animation and avoid storing hundreds of bitmaps.

## Implemented after the design prototype

`voice-envelope.js` exposes testable PCM RMS normalization and a prototype binary visual packet (not a secure transport); `audio-preview.js` connects a local user-selected audio file through Web Audio Analyser and syncs the speaking amplitude to **actual playback**. The local sermon workbench uses the same `sigil.js` renderer. `firmware/src/main.cpp` implements native StickS3 geometry, pending hardware compilation/flashing and secure BLE integration.
