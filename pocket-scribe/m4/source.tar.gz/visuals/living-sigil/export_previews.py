"""Export static device screen assets using the interactive JavaScript canvas source.
Requires playwright Python and a local Chromium executable; serves content via set_content
because local browser navigation is restricted in some environments.
"""
import base64, io
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageOps
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
ASSET = ROOT/'assets'
ASSET.mkdir(exist_ok=True)
MODES = [
    ('idle','01 - REST / PRESENCE'),('listening','02 - LISTENING'),
    ('transcribing','03 - TRANSCRIBING'),('thinking','04 - REFLECTING'),
    ('researching','05 - RESEARCHING'),('writing','06 - COMPOSING'),
    ('speaking','07 - SPEAKING'),('judgment','08 - DISCERNMENT'),
    ('saved','09 - SAVED'),('error','10 - CONNECTION')
]
html = (ROOT/'index.html').read_text()
html = html.replace('<link rel="stylesheet" href="styles.css"/>', f'<style>{(ROOT/"styles.css").read_text()}</style>')
html = html.replace('<script src="sigil.js"></script>', f'<script>{(ROOT/"sigil.js").read_text()}</script>')
fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(fontfile,16)
fontsmall=ImageFont.truetype(fontfile,12)
frames=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1200,'height':1100},device_scale_factor=1)
    errors=[]
    page.on('pageerror', lambda err: errors.append(str(err)))
    page.set_content(html,wait_until='load')
    page.wait_for_timeout(150)
    for mode,label in MODES:
        page.evaluate('(s)=>LivingSigil.setMode(s)',mode)
        if mode=='speaking': page.evaluate('LivingSigil.setVoiceLevel(.75)')
        page.wait_for_timeout(140)
        data=page.locator('#stickCanvas').evaluate('(c)=>c.toDataURL("image/png").split(",")[1]')
        img=Image.open(io.BytesIO(base64.b64decode(data))).convert('RGB')
        native=img.resize((135,240),Image.Resampling.LANCZOS)
        native.save(ASSET/f'{mode}-135x240.png')
        native.resize((405,720),Image.Resampling.NEAREST).save(ASSET/f'{mode}-3x.png')
        frames.append((mode,label,native))
    page.screenshot(path=str(ASSET/'preview-page.png'),full_page=True)
    if errors: raise RuntimeError(errors)
    browser.close()

# Two rows of five cards with labels, generous margins, dark background.
W=5*200+6*18
H=2*365+3*22+70
sheet=Image.new('RGB',(W,H),(7,17,21)); d=ImageDraw.Draw(sheet)
d.text((28,18),'THE LIVING SIGIL  |  8 CORE STATES + 2 STATUS OVERLAYS',font=ImageFont.truetype(fontfile,19),fill=(225,190,127))
for i,(mode,label,img) in enumerate(frames):
    x=18+(i%5)*218;y=70+(i//5)*365
    d.rounded_rectangle((x,y,x+200,y+345),radius=12,fill=(12,25,27),outline=(75,70,51),width=1)
    u=img.resize((169,300),Image.Resampling.NEAREST)
    # UI fits 135x240; enlarge to 169x300, leaving 15px around each preview.
    u=img.resize((169,300),Image.Resampling.LANCZOS)
    sheet.paste(u,(x+15,y+8))
    d.text((x+12,y+318),label,font=fontsmall,fill=(221,218,198))
sheet.save(ROOT/'contact-sheet.png', optimize=True)
print('exported',len(frames),'native screens and contact sheet',ROOT/'contact-sheet.png')
