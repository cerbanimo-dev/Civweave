"""Optional small looping GIF of the live canvas preview: three modes in sequence."""
import base64,io
from pathlib import Path
from PIL import Image
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parent
html=(R/'index.html').read_text().replace('<link rel="stylesheet" href="styles.css"/>','<style>'+(R/'styles.css').read_text()+'</style>').replace('<script src="sigil.js"></script>','<script>'+(R/'sigil.js').read_text()+'</script>')
frames=[]
with sync_playwright() as pw:
    b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=b.new_page(viewport={'width':1100,'height':900})
    page.set_content(html)
    for mode in ['idle','thinking','speaking','researching']:
        page.evaluate('(m)=>LivingSigil.setMode(m)',mode)
        if mode=='speaking':page.locator('#demoAudio').click()
        for i in range(16):
            page.wait_for_timeout(80)
            raw=page.locator('#stickCanvas').evaluate('(c)=>c.toDataURL("image/png").split(",")[1]')
            im=Image.open(io.BytesIO(base64.b64decode(raw))).convert('RGB').resize((270,480),Image.Resampling.LANCZOS)
            frames.append(im)
        if mode=='speaking':page.locator('#demoAudio').click()
    b.close()
frames[0].save(R/'motion-preview.gif',save_all=True,append_images=frames[1:],duration=110,loop=0,optimize=True)
print(R/'motion-preview.gif', (R/'motion-preview.gif').stat().st_size, 'bytes',len(frames),'frames')
