const {test}=require('node:test');
const assert=require('node:assert/strict');
const {MODES,rms,normalize,envelope,encodePacket,decodePacket}=require('../../visuals/living-sigil/voice-envelope.js');
test('silence -> zero, 0.5 amplitude -> 0.5 RMS',()=>{
 assert.equal(rms(new Float32Array(1024)),0);
 assert.ok(Math.abs(rms(new Float32Array([0.5,-0.5,0.5,-0.5]))-0.5)<1e-6);
 assert.equal(normalize(0),0);assert.equal(normalize(1),1);
});
test('normalized audio split into 32ms windows with playback timestamps',()=>{
 const audio=new Float32Array(3200);audio.fill(.2,1600);
 const frames=envelope(audio,1000,32);
 assert.equal(frames.length,100);
 assert.equal(frames[0].playbackMs,0);
 assert.equal(frames[1].playbackMs,32);
 assert.equal(frames[0].level,0);
 assert.ok(frames[60].level>0);
 assert.throws(()=>envelope(audio,0));
});
test('wire packet has stable 12-byte format and roundtrips',()=>{
 for(const mode of MODES){
   const data=encodePacket({seq:65535,playbackMs:4294967295,mode,energy:.8,mic:.2,onset:true});
   assert.equal(data.length,12);const decoded=decodePacket(data);
   assert.equal(decoded.mode,mode);assert.equal(decoded.seq,65535);
   assert.equal(decoded.playbackMs,4294967295);assert.equal(decoded.onset,true);
   assert.ok(Math.abs(decoded.energy-.8)<=1/255);
 }
 assert.throws(()=>encodePacket({mode:'unknown'}));
 assert.throws(()=>decodePacket(Uint8Array.from([0xa5,1])));
});
