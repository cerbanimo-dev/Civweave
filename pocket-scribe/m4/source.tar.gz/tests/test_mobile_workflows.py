"""Standalone-phone workflow parity tests against the browser dev API.
The Android NativeStore uses matching routes, but native behavior requires an Android build/device run.
"""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import urllib.request
from http.server import ThreadingHTTPServer
import threading

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pocket_scribe_m3',ROOT/'server'/'app.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)

class MobileWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();api.DB=Path(cls.tmp.name)/'mobile-test.db'
        with api.open_db():pass
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),api.Handler)
        api.PORT=cls.http.server_address[1]
        cls.url=f'http://127.0.0.1:{api.PORT}'
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close();cls.thread.join(3);cls.tmp.cleanup()
    def request(self,method,path,data=None):
        payload=None if data is None else json.dumps(data).encode()
        req=urllib.request.Request(self.url+path,data=payload,method=method,headers={'Content-Type':'application/json'} if payload else {})
        with urllib.request.urlopen(req,timeout=3) as res:
            return json.loads(res.read())
    def test_full_sermon_edit_search_archive_and_delete(self):
        p=self.request('POST','/api/projects',{'title':'On the Road','passage':'Luke 24'})
        self.assertEqual(p['title'],'On the Road')
        p=self.request('PUT',f'/api/projects/{p["id"]}',{'title':'On the Road to Emmaus','passage':'Luke 24:13-35','occasion':'Sunday','due_date':''})
        self.assertEqual(p['passage'],'Luke 24:13-35')
        a=self.request('POST','/api/notes',{'project_id':p['id'],'title':'Walking together','body':'Their eyes were opened at the table.'})
        b=self.request('POST','/api/drafts',{'project_id':p['id'],'title':'Outline','body':'Opening illustration'})
        b=self.request('PUT',f'/api/drafts/{b["id"]}',{'title':'Revised outline','body':'Walking toward hope','status':'open'})
        self.assertEqual(b['title'],'Revised outline')
        self.assertEqual(len(self.request('GET','/api/search?q=table')),1)
        self.assertEqual(len(self.request('GET','/api/search?q=not-exist-unique')),0)
        archive=self.request('GET','/api/export?project_id='+p['id'])
        self.assertTrue(archive['private'])
        self.assertEqual(len(archive['items']),2)
        recovered=self.request('POST','/api/import',archive)
        self.assertNotEqual(p['id'],recovered['id'])
        entries=self.request('GET','/api/notes?project_id='+recovered['id'])
        self.assertEqual(entries[0]['body'],a['body'])
        self.assertEqual(entries[0]['provenance'],'import')
        self.request('DELETE',f'/api/notes/{a["id"]}')
        self.assertEqual(self.request('GET','/api/notes?project_id='+p['id']),[])
        self.request('DELETE','/api/projects/'+p['id'])
        self.assertEqual(self.request('GET','/api/drafts?project_id='+p['id']),[])
    def test_bad_import_rolls_back(self):
        before=len(self.request('GET','/api/projects'))
        archive={'schema':'kingdom.sermon-project.v1','project':{'title':'This must roll back'},
                 'items':[{'kind':'notes','title':'okay','body':'one'}, {'kind':'not-a-kind','title':'wrong'}]}
        from urllib.error import HTTPError
        with self.assertRaises(HTTPError) as ctx:
            self.request('POST','/api/import',archive)
        self.assertEqual(ctx.exception.code,400)
        self.assertEqual(len(self.request('GET','/api/projects')),before)
    def test_android_assets_have_no_remote_required_dependencies(self):
        assets=ROOT/'android/app/src/main/assets'
        html=(assets/'index.html').read_text()
        self.assertIn('src="sigil.js"',html)
        self.assertIn('src="app.js"',html)
        self.assertIn('href="styles.css"',html)
        self.assertNotIn('https://cdn.',html)
        for required in ['index.html','sigil.js','app.js','styles.css','sigil-demo/index.html','sigil-demo/audio-preview.js']:
            self.assertTrue((assets/required).is_file(),required)
        for filename in ['index.html','sigil.js','app.js','styles.css']:
            orig=ROOT/('visuals/living-sigil/sigil.js' if filename=='sigil.js' else 'web/'+filename)
            self.assertEqual((assets/filename).read_bytes(),orig.read_bytes(),filename)
    def test_android_has_no_mandatory_python_server_or_ble(self):
        activity=(ROOT/'android/app/src/main/java/org/kingdom/pocketscribe/MainActivity.java').read_text()
        self.assertIn('new NativeStore(this)',activity)
        self.assertIn('SpeechRecognizer.createOnDeviceSpeechRecognizer',activity)
        self.assertIn('TextToSpeech',activity)
        self.assertIn('file:///android_asset/index.html',activity)
        self.assertNotIn('http://127.0.0.1:8765/',activity)
        self.assertNotIn('BluetoothDevice',activity)
        self.assertNotIn('setAllowUniversalAccessFromFileURLs(true)',activity)
    def test_workbench_and_preview_served(self):
        for path,marker in [('/','id="voice-note"'),('/app.js','window.PocketMobile'),('/sigil-demo/index.html','sampleFile')]:
            with urllib.request.urlopen(self.url+path,timeout=3) as r:
                self.assertIn(marker,r.read().decode())

if __name__=='__main__':unittest.main()
