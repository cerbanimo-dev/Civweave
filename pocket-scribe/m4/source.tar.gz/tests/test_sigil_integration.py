"""End-to-end HTTP smoke test for the local visual integration.
Never requires network, inference provider, TTS weights or BLE hardware.
"""
import importlib.util
import json
import threading
import tempfile
import urllib.error
import urllib.request
import unittest
from pathlib import Path
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('kingdom_sigil_api',ROOT/'server'/'app.py')
api=importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)

class SigilIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.database=tempfile.TemporaryDirectory()
        api.DB=Path(cls.database.name)/'visual-test.db'
        with api.open_db():pass
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),api.Handler)
        api.PORT=cls.http.server_address[1]
        cls.base=f'http://127.0.0.1:{api.PORT}'
        cls.worker=threading.Thread(target=cls.http.serve_forever,daemon=True)
        cls.worker.start()
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close();cls.worker.join(3)
        cls.database.cleanup()
    def get(self,path):
        with urllib.request.urlopen(self.base+path,timeout=3) as result:
            return result.status,result.headers.get('Content-Type'),result.read().decode('utf-8')
    def test_avatar_is_loaded_in_real_workbench(self):
        status,_,html=self.get('/')
        self.assertEqual(status,200)
        self.assertIn('id="sigilCanvas"',html)
        self.assertIn('<script src="sigil.js"',html)
        self.assertIn('THE LIVING SIGIL',html)
        self.assertNotIn('id="lamp"',html)
    def test_preview_and_audio_envelope_modules(self):
        for path,snippet in [
            ('/sigil-demo/','sampleFile'),
            ('/sigil-demo/styles.css','state-buttons'),
            ('/sigil-demo/sigil.js','window.LivingSigil'),
            ('/sigil-demo/audio-preview.js','getFloatTimeDomainData'),
            ('/sigil-demo/voice-envelope.js','encodePacket'),
        ]:
            with self.subTest(path=path):
                status,_,body=self.get(path)
                self.assertEqual(status,200)
                self.assertIn(snippet,body)
    def test_legacy_server_persists_sermons_unchanged(self):
        req=urllib.request.Request(self.base+'/api/projects',method='POST',
            headers={'Content-Type':'application/json'},
            data=json.dumps({'title':'Visual milestone project','passage':'Luke 15'}).encode())
        with urllib.request.urlopen(req,timeout=3) as response:
            self.assertEqual(response.status,200)
            saved=json.load(response)
        _,_,body=self.get('/api/projects')
        self.assertIn(saved['id'],body)
    def test_no_public_file_browser(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(self.base+'/server/app.py',timeout=3)
        self.assertEqual(ctx.exception.code,404)

if __name__=='__main__':unittest.main()
