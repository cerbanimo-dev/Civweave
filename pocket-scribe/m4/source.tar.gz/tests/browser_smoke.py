"""Desktop Chromium at mobile viewport, exercising the non-native dev backend.
Run: python tests/browser_smoke.py
Requires playwright and a Chromium executable. Does not test Android permissions or APK behavior.
"""
import importlib.util, tempfile, threading, json, os, pathlib
from http.server import ThreadingHTTPServer
from playwright.sync_api import sync_playwright

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pocket_ui_smoke_api',ROOT/'server'/'app.py')
api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api)
tmp=tempfile.TemporaryDirectory()
api.DB=pathlib.Path(tmp.name)/'browser-smoke.sqlite3'
with api.open_db():pass
http=ThreadingHTTPServer(('127.0.0.1',0),api.Handler)
api.PORT=http.server_address[1]
worker=threading.Thread(target=http.serve_forever,daemon=True);worker.start()
base=f'http://127.0.0.1:{api.PORT}/'
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
    page.on('pageerror',lambda exc:errors.append(str(exc)))
    page.on('console',lambda msg:errors.append(msg.text) if msg.type=='error' else None)
    page.goto(base,wait_until='networkidle')
    page.get_by_role('button',name='+ New').click()
    page.locator('#new-title').fill('This Sunday — Luke 15')
    page.locator('#new-passage').fill('Luke 15:11–32')
    page.get_by_role('button',name='Save sermon').click()
    page.get_by_role('button',name='+ Quick note').click()
    page.locator('#entry-title').fill('Older brother resentment')
    page.locator('#entry-body').fill('The older brother saw grace as a scarce resource.')
    page.get_by_role('button',name='Save locally').click()
    page.locator('#search').fill('resentment')
    page.get_by_role('button',name='Search',exact=True).click()
    page.locator('#search-results').get_by_text('Older brother resentment').wait_for()
    page.get_by_role('button',name='Workshop',exact=True).click()
    page.get_by_role('button',name='Sermon outline template').click()
    assert 'Central message:' in page.locator('#entry-body').input_value()
    page.locator('#entry-body').fill('Intro: Lost, then found.\nApplication: receive mercy.')
    page.get_by_role('button',name='Save locally').click()
    page.get_by_text('Sermon Outline —',exact=False).wait_for()
    page.locator('button[data-edit]').click()
    page.locator('#entry-title').fill('Edited sermon outline')
    page.get_by_role('button',name='Save locally').click()
    page.get_by_text('Edited sermon outline').wait_for()
    with page.expect_download() as download_info:
        page.get_by_role('button',name='Export current sermon').click()
    download=download_info.value
    target=pathlib.Path(tmp.name)/download.suggested_filename
    download.save_as(target)
    data=json.loads(target.read_text())
    assert data['schema']=='kingdom.sermon-project.v1'
    assert len(data['items'])==2
    page.screenshot(path='/mnt/data/pocket-scribe-mobile-m3-preview.png',full_page=True)
    print('BROWSER SMOKE: project, note, search, manual outline, edit, export: passed')
    print('ARCHIVE:',target.name,'items',len(data['items']))
    print('JS errors:',errors)
    if errors:raise Exception('Browser errors: '+' | '.join(errors))
    browser.close()
http.shutdown();http.server_close();worker.join(3);tmp.cleanup()
