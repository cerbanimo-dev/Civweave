import importlib.util
import unittest
from pathlib import Path

module_path=Path(__file__).resolve().parents[1]/'tools'/'serial_demo.py'
spec=importlib.util.spec_from_file_location('kingdom_serial_demo',module_path)
serial=importlib.util.module_from_spec(spec)
spec.loader.exec_module(serial)

class SerialCommandTests(unittest.TestCase):
    def test_mode_numbers_match_firmware(self):
        self.assertEqual(serial.command_bytes('speaking',160),b'S 6\nE 160\n')
        self.assertEqual(serial.command_bytes('thinking'),b'S 3\nE 0\n')
    def test_rejects_out_of_range(self):
        for v in (-1,256,2.5,True):
            with self.subTest(level=v),self.assertRaises(ValueError):serial.command_bytes('speaking',v)
        with self.assertRaises(ValueError):serial.command_bytes('something-else')
if __name__=='__main__':unittest.main()
